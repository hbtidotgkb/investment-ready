# Newsdesk and the News Brain: setup and usage guide

Newsdesk collects stock news from exchange filings and the financial press, checks
press claims against the filings, scores each event, and builds a cited **dossier**
per stock. The **news brain** reads that dossier and writes a structured, cited news
view for the Head CA.

This guide covers everything needed to run both on your own machine.

**Contents**
1. How it fits together
2. Install and run
3. Running on your cloud VM
4. Sources: what's used and why
5. How Newsdesk works
6. Configuration
7. Adding stocks
8. The UI
9. ET Prime capture extension
10. API reference
11. The news brain
12. Worked example: BSE Ltd
13. TradingView MCP and the nse-bse-mcp server
14. Known gaps and next steps
15. Troubleshooting
16. Usage and legal notes

---

## 1. How it fits together

```
 Exchange filings (BSE, NSE, SEBI, RBI) ─┐
 Company news search (by publisher)      ├─► Newsdesk ─► dossier per stock ─► News brain ─► news view
 Market news feeds (ET, BS, Mint, MC)    │   (stores,        (ranked events,     (Claude /     (JSON, cited)
 ET Prime articles you open (extension) ─┘    checks,        citations,          Gemini /          │
                                              scores)        coming up)          ChatGPT)          ▼
                                                                                              Critic (script)
                                                                                                   │
                     Fundamentals brain ──┐                                                        ▼
                     Technicals brain   ──┼──────────────────────────────────────────────────► Head CA ─► you decide
                     (Kite, filings)    ──┘
```

- **Newsdesk** does the slow, careful work in the background: fetching, matching
  news to stocks, merging duplicates, checking claims against filings, and ranking.
- **The news brain** is an LLM call. It reads one prepared dossier, follows fixed
  rules, and answers in a fixed format. It doesn't browse or remember anything.
- **The critic** is plain code. It checks that every point the brain makes is
  backed by a real citation.
- **The Head CA** weighs the news view against the fundamentals and technicals views.

---

## 2. Install and run

You need Python 3.10 or newer.

```
unzip newsdesk.zip
cd newsdesk
python3 -m venv .venv
. .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt   # requests, pyyaml, pypdf
python run.py serve
```

Open **http://127.0.0.1:8765**. The first visit to a stock fetches from every
source, which can take 20–30 seconds.

### Commands

| Command | What it does |
|---|---|
| `python run.py serve` | UI and API, with the background worker |
| `python run.py serve --no-worker` | UI and API only; fetching on demand still works |
| `python run.py fetch` | Poll every source once and exit |
| `python run.py check RELIANCE` | Test every source for one stock: what came back, what matched, what failed |
| `python run.py dossier LT --md` | Print a dossier |
| `python run.py nightly` | Run the nightly re-score and trust update now |
| `python news_brain.py RELIANCE` | Run the news brain on a stock (section 11) |
| `python -m unittest discover tests` | Offline tests (22) |

### Settings (environment variables)

| Variable | Purpose |
|---|---|
| `NEWSDESK_INGEST_TOKEN` | Secret the extension must send. **Set this** (section 9). |
| `ANTHROPIC_API_KEY` | Better event labels and summaries in Newsdesk; also the Claude news brain |
| `NEWSDESK_DB` | Database location (default `data/newsdesk.db`) |
| `NEWSDESK_URL` | Where `news_brain.py` finds Newsdesk (default `http://127.0.0.1:8765`) |
| `OPENAI_API_KEY`, `OPENAI_MODEL` | ChatGPT as a news brain |
| `GEMINI_API_KEY`, `GEMINI_MODEL` | Gemini as a news brain |

Generate the ingest token with:

```
python3 -c "import secrets; print(secrets.token_urlsafe(24))"
```

---

## 3. Running on your cloud VM

Run it on the VM so it keeps collecting while your laptop sleeps. Otherwise you
miss the after-market results, which are filed in the evening.

```
tmux new -s newsdesk
cd newsdesk && . .venv/bin/activate
export NEWSDESK_INGEST_TOKEN=<your token>
python run.py serve
# Ctrl+B, then D, to detach
```

Newsdesk only listens on the VM itself. To reach it from your laptop, open an SSH tunnel:

```
ssh -L 8765:127.0.0.1:8765 user@your-vm
```

Then http://127.0.0.1:8765 on your laptop reaches the VM's Newsdesk. The extension
uses the same address, so keep the tunnel open while you read ET Prime.

---

## 4. Sources: what's used and why

### In Newsdesk

| Source | What it gives | Tier | Starting trust |
|---|---|---|---|
| BSE corporate announcements | Every filing; the attached PDF is read for its figures | 0 | 0.98 |
| NSE announcements (RSS) | NSE filings, headlines only | 0 | 0.98 |
| SEBI | Orders, notices, circulars | 0 | 0.98 |
| RBI | Press releases, penalties on banks | 0 | 0.97 |
| Company news search (Google News) | Recent press about one stock, credited to the real publisher | per publisher | — |
| Economic Times Markets | Market-wide headlines | 1 | 0.80 |
| ET Prime | Headlines from the feed; full text through the extension | 1 | 0.85 |
| Business Standard | Market-wide headlines | 1 | 0.80 |
| Mint | Market-wide headlines | 1 | 0.78 |
| Moneycontrol | Market-wide headlines | 1 | 0.70 |
| Reuters, CNBC-TV18, BusinessLine, Financial Express, NDTV Profit | Through the company search | 1 | 0.72–0.90 |
| Other outlets | Anything else the search finds | 2 | 0.55 |

**Tier 0 is ground truth.** Listed companies must file material events with the
exchanges under SEBI's listing rules. Press claims are checked against these filings.

**Trust is learned.** Every night, each press source's trust moves toward its record:
claims later confirmed by a filing raise it, mismatches lower it. You can see each
source's record in the Sources tab.

**Why the RSS feeds aren't enough on their own.** They only carry the latest
market-wide headlines, so they rarely have anything about one particular stock. The
company search is what finds a stock's news.

### Where the filing PDFs come from

From BSE's own servers. Each announcement links to the document the company filed:

```
https://www.bseindia.com/xml-data/corpfiling/AttachLive/<file>.pdf
```

For watchlist stocks, Newsdesk downloads it and reads up to 6 pages (20,000 characters).
That's how "Disclosure under Regulation 30" becomes "received an order worth ₹2,100 crore".

Limits:
- **Scanned PDFs** have no text layer and yield nothing.
- **Long reports** are cut off after the limit.
- **NSE filings** arrive without their PDF.

### Deliberately not used in Newsdesk

| Source | Why not |
|---|---|
| TradingView | Its terms don't allow storing its data in a database. Use its MCP in chat instead (section 13). |
| Bloomberg, Reuters/LSEG feeds | Enterprise pricing; Indian press relays their India stories quickly |
| Social media, Telegram, forums | Too noisy; a rumour-signal layer could be added later, but never feeding the dossier directly |
| Screener, CMIE | Fundamentals, not news; they belong to the fundamentals brain |

---

## 5. How Newsdesk works

### Two ways of running

**In the background (the worker).** Every 30 seconds it checks which sources are due.
Polling frequency depends on the market phase (IST):

| Phase | Hours | Filings | Press |
|---|---|---|---|
| Overnight | 22:00–07:00, weekends | every 30 min | 30–60 min |
| Pre-market | 07:00–09:15 | every 10 min | 10–20 min |
| Market | 09:15–15:30 | every 2 min | 5–15 min |
| Post-market | 15:30–22:00 | every 2 min | 5–15 min |

It also runs three fixed jobs:
- **07:00:** sweep every source.
- **08:45:** sweep again, then pre-build every watchlist dossier, ready for the open.
- **23:00:** nightly maintenance: decay scores, re-check unconfirmed claims against
  the day's filings, and update source trust.

Whenever a poll changes a stock's events, that stock's dossier is rebuilt straight away.

**On demand.** When you open a stock or request its dossier, Newsdesk checks how fresh
its data is. If it's older than 2 minutes during market hours (30 minutes otherwise),
it first:
- pulls that stock's BSE filings
- runs the company news search
- makes one pass over the feeds

Then it builds the dossier. **Refresh now** skips the freshness check.

### What happens to each article

1. **Drop paid and routine items.** Sponsored content ("Brand Connect", "partner
   content") and paperwork filings (trading-window closures, newspaper copies,
   share-certificate notices) are kept on record but not used.
2. **Match to stocks.** This uses the stock's names (section 6), its BSE scrip code,
   or a symbol tag. Each match gets a salience score:
   - 1.0: the article is about the company
   - 0.4: it only names a subsidiary or asset
   - below 0.3: a passing mention, which is dropped
3. **Read the filing PDF** for tier-0 matches.
4. **Label it.** The event type (results, order win, regulatory action, governance
   concern…), direction, and fact versus speculation versus opinion. It also extracts
   rupee amounts and up to 3 checkable claims. This step is rule-based, or uses Claude
   if `ANTHROPIC_API_KEY` is set.
5. **Merge into an event.** Articles about the same thing within a few days become
   one event with several citations.
6. **Check against filings.** Each press claim becomes:
   - **filed:** from the filing itself
   - **confirmed:** a filing matches it, amounts within 5%
   - **contradicted:** a filing gives a different figure
   - **denied:** the company filed a clarification denying it
   - **unconfirmed:** no filing yet
   - **investigative:** a governance or accounting report from the press, such as ET Prime
7. **Score it:**
   ```
   score = materiality × confidence × recency
   ```
   - **Materiality:** set by event type, raised when the rupee amount is large
     relative to market cap.
   - **Confidence:** grows with independent sources and filings; cut for denied,
     contradicted, speculation, opinion, or headline-only events.
   - **Recency:** halves on a schedule that depends on event type. Analyst views
     fade in 3 days; regulatory actions last about 2 months; governance concerns about 3 months.
8. **Alert** on new filings, high-impact events, and press reports a filing contradicts.

### What's in a dossier

| Part | Contents |
|---|---|
| Events | Up to 15, ranked by score, each with status, type, claims and citations |
| Coming up | Results dates, record dates and earnings calls from the company's own notices |
| Check these first | Contradicted or denied reports, and events where sources disagree on direction |
| Not known yet | Unconfirmed material events, headline-only articles, missing filings |
| Citations | Numbered sources: publisher, tier, link, times, a quote, and the SHA-256 hash of the saved text |

---

## 6. Configuration

### `config/sources.yaml`

| Key | Purpose |
|---|---|
| `sources` | Each source's id, tier, starting trust, feed URL and polling cadence per market phase |
| `gnews.publishers` | Maps publisher names in search results to sources, which sets their tier and trust |
| `routine_filings` | Regex patterns for paperwork filings to skip |
| `paid_markers` | Phrases that mark sponsored content |
| `provider_names` | Publisher mapping for items posted through the batch API |
| `llm` | Model used for labelling when `ANTHROPIC_API_KEY` is set |
| `freshness` | How stale data can be before an on-demand request fetches first |

Feed URLs change from time to time. After the first run, check the Sources tab and
fix any feed that shows an error.

### `config/watchlist.yaml`

```yaml
- ticker: RELIANCE                # NSE symbol
  name: Reliance Industries
  bse_scrip: "500325"             # from the company's bseindia.com page
  aliases: [Reliance Industries, RIL]          # identify the company; used for news search
  link_only: [Reliance]                        # press shorthand, too broad to search with
  related: [Jio Platforms, Reliance Jio, Jio, Reliance Retail, Jamnagar refinery]
  exclude: [Reliance Power, Reliance Infrastructure, Reliance Capital, Anil Ambani, ...]
  market_cap_cr: 1900000          # rough, in ₹ crore; sizes how material an amount is
```

- **`aliases`:** names that identify the company. They're also used for the news search.
- **`link_only`:** shorthand like "Reliance" or "HDFC". These catch most headlines,
  but only work safely with a good `exclude` list.
- **`related`:** subsidiaries, brands and assets. A headline naming only these is
  kept, ranked below news about the company itself.
- **`exclude`:** look-alikes, removed before matching, so "Reliance Power" never
  matches "Reliance".

---

## 7. Adding stocks

In the UI, use "Add a stock", or edit `watchlist.yaml` and restart. Recent articles
that matched nothing are re-checked for the new stock, so news from the last 30 days
links straight away.

Always give the **BSE scrip code** where one exists. Without it, the stock gets no
BSE filings, which means no tier-0 checks and no "Coming up". Find it on the
company's page at bseindia.com.

A few companies list only on NSE, such as BSE Ltd itself. They depend on NSE
filings, which are weak today (section 14).

---

## 8. The UI

- **Left:** watchlist (a red count means unseen alerts), "Add a stock", and the views:
  Dossier, Alerts, Sources.
- **Centre:** the dossier.
  - **Time window:** 7, 30, 90 or 180 days.
  - **Copy for brain:** copies the text form that the news brain reads.
  - **Refresh now:** fetches regardless of freshness.
  - The status line says how many items came from how many sources, and names any
    source that couldn't be reached.
- **Each event:**
  - Its status in colour: Company filing, Confirmed by filing, Press only, Doesn't
    match the filing, Denied by the company, or Investigative report.
  - Claims with numbered citations.
  - A strip of marks, one per source: solid for a filing, outlined for press,
    dashed for headline only.
  - Its weight and confidence.
- **Right:** the sources cited. Clicking a citation number highlights its source.
  "View saved copy" shows the exact text stored, with its hash.

---

## 9. ET Prime capture extension

The feed only gives ET Prime headlines. The extension adds the full text of the
articles you open. It never fetches, scrolls or logs in by itself.

### Install

1. Open `chrome://extensions` and turn on Developer mode.
2. Click "Load unpacked" and pick the `extension` folder. For an update, click the
   reload icon on "Newsdesk capture" instead.
3. Click the extension icon. Enter the Newsdesk address if it's not
   `http://127.0.0.1:8765`, paste your ingest token, and click "Save settings".

### Use

Open an ET Prime article while logged in. Within about 15 seconds the icon shows:
- **✓** sent
- **!** Newsdesk not reachable, or wrong token
- **?** too little text found

The popup lists the last 25 captures, each with a line saying which stocks it linked
to, or "Saved; no watchlist stock mentioned". **Capture this page** reruns the capture
on the current tab and reports how many characters it found, and how.

### Where captured articles go

Into Newsdesk's database. A captured article:
- replaces its headline-only record
- links to any watchlist stocks it names
- re-scores the event

If it names no watchlist stock, it's stored unlinked, and adding that stock later links it.

To list recent captures:

```
sqlite3 data/newsdesk.db "SELECT id, title, dropped_reason FROM articles WHERE source_id='et_prime' ORDER BY id DESC LIMIT 10"
```

To read one: `http://127.0.0.1:8765/api/article/<id>`.

### Why set the token

Any website open in your browser can send requests to `127.0.0.1`. Without a token,
a malicious page could post fake articles into your dossiers, and the brains would
treat them as real. The token only guards the capture endpoints.

---

## 10. API reference

| Method and path | Purpose |
|---|---|
| `GET /api/dossier/{TICKER}` | Dossier as JSON. `?refresh=auto` (default), `force` or `no`. `?days=7…365` |
| `GET /api/dossier/{TICKER}?format=md` | Dossier as text for a brain's prompt |
| `GET /api/article/{id}` | One stored article: full text, source, times, hash |
| `GET /api/watchlist` | Stocks with last fetch time and unseen alerts |
| `POST /api/watchlist` | Add or update a stock: `{ticker, name, bse_scrip, aliases, link_only, related, exclude}` |
| `GET /api/sources` | Each source's health, item count and track record |
| `GET /api/alerts` / `POST /api/alerts/seen` | Alerts |
| `POST /api/ingest` | One article: `{url, title, body, published_at?, source? or provider?, symbols?}` |
| `POST /api/ingest/batch` | Headlines from another tool of yours: `{items: [{url, title, provider, symbols, published_at}]}` |

The two ingest endpoints require the `X-Ingest-Token` header when a token is set.

---

## 11. The news brain

### Its job

Turn one dossier into a **news view**: stance, drivers, risks, catalysts, whether it's
priced in, and what's unknown, with every point cited. It does not decide trades.
The Head CA weighs its view with the fundamentals and technicals views, and you decide.

### The flow for one stock

1. **Fetch the dossier.** Text for the prompt, JSON for the critic.
2. **Pass 1, scan.** The brain reads the dossier and names up to 5 citations it
   wants in full, preferring filings and ET Prime.
3. **Pass 2, read and write.** Those articles' saved text (up to 6,000 characters
   each) is added, and the brain writes its view.
4. **The critic checks it:**
   - every citation exists
   - no driver rests only on opinion
   - no driver uses a denied or contradicted report
   - every figure appears in the cited text
   - the stance is one of the allowed values
5. **Save the view** to `data/brain_views/<TICKER>-<brain>-<time>.json` for the Head CA.

Two passes give depth where it matters without pasting a month of articles into one
prompt. That would cost more, and most of it would be repetition.

### The rules every brain follows

- Use only the dossier and attached articles, and cite every point.
- Filed and confirmed are strong evidence; unconfirmed, speculation and opinion are
  weak; denied and contradicted count against a report.
- Analyst targets and ratings are opinion, never drivers.
- Price moves are context for "already priced in", not drivers.
- "Coming up" items haven't happened yet.
- Say what's unknown rather than filling gaps.

### The output format

```json
{
  "stance": "positive | negative | neutral | mixed",
  "strength": 0.6,
  "horizon": "days | weeks | months",
  "drivers": [{"point": "...", "direction": "+", "citations": [1, 2]}],
  "risks": [{"point": "...", "citations": [5]}],
  "catalysts": [{"date": "2027-01-15", "what": "Q3 results", "citations": [9]}],
  "already_priced_in": "partly: stock up ~20% in a month [8]",
  "would_change_my_view": ["..."],
  "gaps": ["..."]
}
```

### Running it

```
export ANTHROPIC_API_KEY=...
python news_brain.py RELIANCE                  # Claude
python news_brain.py RELIANCE --brain openai   # needs OPENAI_API_KEY and OPENAI_MODEL
python news_brain.py RELIANCE --brain gemini   # needs GEMINI_API_KEY and GEMINI_MODEL
python news_brain.py BSE --days 90 --no-refresh
python news_brain.py RELIANCE --dry-run        # print the prompts; call no model
```

It prints the saved record. The exit code is 0 if the critic passed and 2 if it
found problems, which are listed in the record under `critic.problems`.

`--dry-run` is the best way to see exactly what a brain receives.

### Running several brains fairly

Run the same ticker through each brain without `--no-refresh` only on the first, so
all of them read the identical dossier:

```
python news_brain.py RELIANCE --brain claude
python news_brain.py RELIANCE --brain openai --no-refresh
python news_brain.py RELIANCE --brain gemini --no-refresh
```

Differences in their views then come from reasoning, not from different news. Each
record stores `dossier_as_of`, so the Head CA can confirm they match.

### What the Head CA does with it

- It reads each brain's news view that passed the critic, along with the
  fundamentals and technicals views.
- Where the news brains disagree, it looks at the citations each one used.
- It discounts views whose drivers are all press-only.
- It gives the verdict with the citations carried through.

A view that failed the critic should be re-run, or set aside, never used silently.

---

## 12. Worked example: BSE Ltd

**What the brain receives** (shortened):

```
1. BSE shares jump nearly 4% after Q2 profit rises 45% [3][4]
   type=results status=unconfirmed kind=opinion confidence=0.45 sources=2
2. BANKEX becomes first Indian sectoral index futures approved by US CFTC [12][13][14][15]
   status=unconfirmed kind=fact confidence=0.75
3. SEBI chief says considering limit for MTF, no decision yet [5][6]
4. BSE shares jump 20% in a month [8][9]
5. BSE Ltd is Rated Buy by MarketsMOJO [18][19]  kind=opinion
## Not yet known
- No exchange filings for BSE in the last 90 days.
```

**How it reasons:**
- MarketsMOJO and broker targets are opinion, so they're ignored.
- The CFTC approval has 4 citations, so it's the strongest point.
- No filing confirms the 45% profit figure.
- The stock is already up 20%, so the good news is partly priced in.

**What it writes:**

```json
{
  "stance": "positive", "strength": 0.45, "horizon": "weeks",
  "drivers": [
    {"point": "Q2 profit up about 45%, press-only, not yet checked against a filing", "direction": "+", "citations": [3]},
    {"point": "US CFTC approved BANKEX futures, a new revenue line; reported by 4 outlets", "direction": "+", "citations": [12, 13, 14, 15]}
  ],
  "risks": [{"point": "SEBI may cap margin-trading funding; no decision yet", "citations": [5, 17]}],
  "catalysts": [],
  "already_priced_in": "partly: stock up ~20% in a month [8]",
  "would_change_my_view": ["SEBI announcing MTF limits", "NSE results filing with weaker numbers"],
  "gaps": ["No exchange filings", "No revenue or volume figures", "No next results date"]
}
```

**The critic:** all citations exist, no driver rests on opinion, and "45" is in
citation 3. The view passes.

**The Head CA:**

> News mildly positive but unconfirmed. Strong quarter and a new US product, with a
> regulatory overhang, and much of it already priced in. Low confidence until the NSE
> results filing is checked.

**What this example shows about the dossier** (see section 14):
- no filings, because BSE Ltd lists only on NSE
- the same story split into several events
- junk such as a live price page and robo-written ratings
- the CFTC approval ranked too low

---

## 13. TradingView MCP and the nse-bse-mcp server

### TradingView MCP: on demand, in chat

TradingView's official MCP gives:
- per-symbol news (up to 200 headlines, with provider and related symbols)
- full story text
- fundamentals, price history and technicals
- filings and transcripts
- an economic calendar

It's a useful cross-check, used **on demand in chat only**. Its terms say:
- **Personal use only:** not for work, and not shared.
- **No storing:** its data can't feed a database or a data feed, so it can't be a
  Newsdesk source.
- **No automated trading decisions:** answers to your questions are fine.

Daily calls depend on your plan: 10 on Essential, 50 on Premium, and 500 on Ultimate
or with the AI add-on. A single stock analysis can take 6–10 calls.

Connect it with your **personal** account, not your work one:

- **claude.ai:** Settings → Connectors → "TradingView MCP" → Connect → log in and Allow.
- **Claude Code on the VM:**
  ```
  claude mcp add --transport http mcp-tradingview https://mcp.tradingview.com/mcp
  ```
  Then run `/mcp` and log in.

Allow only the read tools, so it can't change your watchlists or alerts.

Example use:

> Fetch the RELIANCE dossier from Newsdesk, then get TradingView's latest RELIANCE
> headlines, and tell me what TradingView has that the dossier is missing.

### nse-bse-mcp: NSE filings and the results calendar

An open-source (MIT) MCP server wrapping NSE and BSE's own endpoints. It has 60
tools, including:
- NSE corporate announcements, board meetings and corporate actions
- the BSE result calendar
- block and bulk deals
- market holidays
- a document downloader

It's early-stage and calls the same unofficial endpoints, so test it before relying on it.

```
git clone https://github.com/bshada/nse-bse-mcp && cd nse-bse-mcp
bun install && bun run build && bun start        # serves http://localhost:3000/mcp
claude mcp add --transport http nse-bse http://localhost:3000/mcp
```

Keep it on localhost. Clone and read the code rather than running `npx`, which
fetches whatever is newest on npm.

Test, in Claude Code:
- "Use nse-bse to get RELIANCE corporate announcements from the last 30 days"
- "Use nse-bse to get the BSE result calendar for this month"
- "Use nse-bse to get NSE market holidays"

If the NSE calls return data, it can become Newsdesk's NSE filings source (section 14).

---

## 14. Known gaps and next steps

| # | Gap | Effect | Fix |
|---|---|---|---|
| 1 | **NSE filings are weak.** The RSS has headlines only, and its URL is unverified. | NSE-only stocks (like BSE Ltd) have no tier-0 checks | NSE announcements through nse-bse-mcp, as a tier-0 source |
| 2 | **Headline-only stories don't merge well.** | The same story appears as several events | Match on distinctive words (BANKEX, CFTC, Q2) within a few days; merge results stories across labels |
| 3 | **Junk gets in.** | Live price pages, robo-written ratings and previews | Low-quality publisher list and title patterns in config |
| 4 | **Some events are mislabelled.** | Approvals and launches ranked as "Other"; price moves treated as news | New "business development" type ranked high; price moves weighted lowest; weekly recaps merged |
| 5 | **Search results have no article text.** | Most press events have headlines only | Resolve publisher links and fetch article text for the top events |
| 6 | **No price check.** | "Already priced in" is left to the brain | Use Kite to measure the move since each event (hook in `scoring.py`) |
| 7 | **Exchange holidays aren't modelled.** | Polling on holidays (harmless) | Holiday list from nse-bse-mcp |
| 8 | **Scanned filing PDFs** | No figures from them | OCR for image-only PDFs |

Gaps 2–4 are self-contained. Gaps 1, 5 and 7 depend on live sites, so test them on your machine.

---

## 15. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| A stock shows no events | Run `python run.py check TICKER`. **FAILED** rows mean a source isn't reachable from your network. **ok** with 0 matches means its names need work: add `link_only` names, or check `exclude`. |
| Status line names sources as not reachable | Open the Sources tab for the error. Feed URLs change; update `sources.yaml`. |
| "No BSE scrip code for this stock" | Add `bse_scrip` from bseindia.com |
| Extension shows **?** | Wait until the article is fully on screen, then click "Capture this page". If it still finds only a few hundred characters, the extraction needs tuning: copy the article container's outerHTML (right-click a paragraph, Inspect, right-click the container, Copy outerHTML). |
| Extension shows **!** | Newsdesk isn't running, the SSH tunnel is closed, or the token differs (re-paste it, no spaces) |
| "Sent" but not in any dossier | It names no watchlist stock. Add the stock, and it links automatically. |
| A wrong company's news appears | Add the look-alike name to that stock's `exclude` |
| Critic fails a view | Read `critic.problems` in the saved record; re-run, or set the view aside |
| `news_brain.py` HTTP 401/403 | API key missing or wrong for that brain |

---

## 16. Usage and legal notes

- **Personal use.** This setup is for your own research. ET Prime content captured
  through your subscription, and anything from TradingView, can't be shared with others.
- **Before going public under SEBI registration:**
  - switch to **licensed** news feeds and an authorised exchange data vendor
  - drop the unofficial NSE/BSE endpoints
  - drop the ET Prime capture
- **Analysis, not advice.** The brains describe evidence. Decisions are yours. Check
  the cited filing before acting on any figure.
- **Keep work and personal separate.** Use your personal Claude and TradingView
  accounts for this project, not your employer's.
