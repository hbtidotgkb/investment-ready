"""newsdesk entry point.

  python run.py serve            UI + API on http://127.0.0.1:8765, with the async worker
  python run.py serve --no-worker   UI + API only (on-demand fetching still works)
  python run.py fetch            poll every source once, then exit
  python run.py dossier LT [--md]   print a dossier
  python run.py nightly          run the nightly maintenance job now
  python run.py check RELIANCE   test every source for one stock and show what matched
"""
import argparse
import json
import logging
import sys

from newsdesk import dossier
from newsdesk.db import connect
from newsdesk.pipeline import bootstrap, rescore_all
from newsdesk.worker import Worker, refresh_ticker, run_source


def main():
    ap = argparse.ArgumentParser(description="Stock news dossiers for the news brain")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8765)
    s.add_argument("--no-worker", action="store_true")
    sub.add_parser("fetch")
    d = sub.add_parser("dossier")
    d.add_argument("ticker")
    d.add_argument("--md", action="store_true")
    d.add_argument("--no-refresh", action="store_true")
    sub.add_parser("nightly")
    c = sub.add_parser("check")
    c.add_argument("ticker")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()

    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(name)s %(levelname)s %(message)s")
    conn = connect()
    cfg = bootstrap(conn)

    if a.cmd == "serve":
        from newsdesk.server import serve
        if not a.no_worker:
            Worker().start()
        serve(a.host, a.port)
    elif a.cmd == "fetch":
        for src in cfg["sources"]:
            run_source(conn, src, cfg)
    elif a.cmd == "dossier":
        if not a.no_refresh:
            refresh_ticker(conn, cfg, a.ticker)
        out = dossier.build(conn, a.ticker)
        if out is None:
            sys.exit(f"{a.ticker.upper()} isn't on the watchlist. Add it to config/watchlist.yaml.")
        print(dossier.to_markdown(out) if a.md else json.dumps(out, indent=2, ensure_ascii=False))
    elif a.cmd == "nightly":
        rescore_all(conn)
    elif a.cmd == "check":
        check(conn, cfg, a.ticker.upper())


def check(conn, cfg, ticker):
    """Fetch each source for one stock and report what came back and what linked."""
    from newsdesk import sources
    from newsdesk.linker import Linker
    from newsdesk.worker import FETCHED, stock_aliases
    stock = conn.execute("SELECT * FROM watchlist WHERE ticker=?", (ticker,)).fetchone()
    if not stock:
        sys.exit(f"{ticker} isn't on the watchlist. Add it in the UI or config/watchlist.yaml.")
    linker = Linker.from_db(conn)
    print(f"{ticker}: aliases {stock_aliases(stock)}, BSE scrip {stock['bse_scrip'] or 'none'}\n")
    for src in cfg["sources"]:
        if src["kind"] not in FETCHED:
            continue
        kw = {}
        if src["kind"] == "bse":
            if not stock["bse_scrip"]:
                print(f"{src['id']:<18} skipped (no BSE scrip code)")
                continue
            kw = {"scrip": stock["bse_scrip"], "days": 30}
        elif src["kind"] == "gnews":
            kw = {"aliases": stock_aliases(stock), "days": 30}
        try:
            items = sources.fetch(src, **kw)
        except Exception as e:
            print(f"{src['id']:<18} FAILED  {type(e).__name__}: {str(e)[:150]}")
            continue
        hits = [i for i in items if ticker in linker.link(i.title, i.body, i.scrip)]
        print(f"{src['id']:<18} ok      {len(items):>3} items, {len(hits):>3} about {ticker}")
        for i in hits[:3]:
            print(f"{'':<26}- {i.title[:90]}")


if __name__ == "__main__":
    main()
