import os
from pathlib import Path

import yaml

ROOT = Path(os.environ.get("NEWSDESK_HOME", Path(__file__).resolve().parent.parent))
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
DB_PATH = Path(os.environ.get("NEWSDESK_DB", DATA_DIR / "newsdesk.db"))


def load_yaml(name):
    with open(CONFIG_DIR / name, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_sources():
    return load_yaml("sources.yaml")


def load_watchlist_file():
    return load_yaml("watchlist.yaml").get("stocks", [])
