// Posts captured articles to Newsdesk and shows the result on the toolbar icon.
const DEFAULTS = { server: "http://127.0.0.1:8765", token: "" };

async function settings() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(["server", "token"])) };
}

async function remember(entry) {
  const { history = [] } = await chrome.storage.local.get("history");
  history.unshift({ ...entry, at: new Date().toISOString() });
  await chrome.storage.local.set({ history: history.slice(0, 25) });
}

function badge(tabId, text, color) {
  chrome.action.setBadgeText({ tabId, text });
  chrome.action.setBadgeBackgroundColor({ tabId, color });
}

async function post(path, payload) {
  const { server, token } = await settings();
  const r = await fetch(`${server.replace(/\/$/, "")}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token ? { "X-Ingest-Token": token } : {}) },
    body: JSON.stringify(payload),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

const linked = (data) => [...new Set((data.events_changed || []).map((e) => e.ticker))];
const unreachable = async (e) => `${e.message}. Is Newsdesk running at ${(await settings()).server}?`;

chrome.runtime.onMessage.addListener((msg, sender) => {
  const tabId = sender.tab?.id;
  if (msg.type === "too_short") {
    badge(tabId, "?", "#8F6400");
    remember({ url: msg.url, title: msg.title, status: "skipped", detail: `Found only ${msg.chars} characters of article text (${msg.how}). Try "Capture this page" in this popup once the article is fully on screen; if that also fails, the page layout needs a fix.` });
    return;
  }

  if (msg.type === "capture") {
    (async () => {
      try {
        const data = await post("/api/ingest", {
          url: msg.url, title: msg.title, body: msg.body, published_at: msg.published_at,
          ...(msg.provider ? { provider: msg.provider, symbols: msg.symbols } : { source: "et_prime" }),
        });
        const t = linked(data);
        badge(tabId, "✓", "#1D6B5F");
        remember({ url: msg.url, title: msg.title, status: "sent",
                   detail: t.length ? `Linked to ${t.join(", ")}` : "Saved; no watchlist stock mentioned" });
      } catch (e) {
        badge(tabId, "!", "#A2402B");
        remember({ url: msg.url, title: msg.title, status: "failed", detail: await unreachable(e) });
      }
    })();
  }

});
