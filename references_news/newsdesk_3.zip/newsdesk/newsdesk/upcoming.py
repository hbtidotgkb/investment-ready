"""Scheduled company events (results, board meetings, record dates) read from the
company's own filings: the notice a company must file before a board meeting."""
import re
from datetime import date, datetime, timedelta

from .clock import IST, now_utc

MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july", "august",
     "september", "october", "november", "december"], 1)}
MON = "|".join(list(MONTHS) + [m[:3] for m in MONTHS] + ["sept"])

DATE_PATTERNS = [
    # January 15, 2027 / Jan 15 2027
    (re.compile(rf"\b({MON})\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?,?\s+(\d{{4}})\b", re.I), "mdy"),
    # 15th January, 2027 / 15 Jan 2027
    (re.compile(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s+(?:of\s+)?({MON})\.?,?\s+(\d{{4}})\b", re.I), "dmy"),
    # 15/01/2027, 15-01-2027, 15.01.2027 (Indian order)
    (re.compile(r"\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})\b"), "dnum"),
]

NOTICE = re.compile(r"board meeting|meeting of the board|intimation|record date|"
                    r"book closure|earnings call|annual general meeting|\bagm\b", re.I)

# A sentence that schedules something, and words that mark a date as a period or window.
EVENT_SENTENCE = re.compile(r"(meeting|record date|book closure|earnings call|conference call|agm)"
                            r".*\b(held|scheduled|convened|fixed|on)\b|\b(held|scheduled|fixed)\b.*meeting|"
                            r"record date", re.I)
NOT_EVENT_DATE = re.compile(r"(ended|ending|period|from|till|until|up ?to|closed|w\.?e\.?f\.?|"
                            r"dated|letter|since)\s*(on\s*)?(\w+day,?\s*)?$", re.I)

PURPOSES = [
    ("Results", r"financial results|audited|unaudited|quarter(ly)? results"),
    ("Dividend", r"dividend"),
    ("Fundraise", r"fund ?rais|non.convertible|debentures|\bqip\b|preferential|rights issue"),
    ("Buyback", r"buy.?back"),
    ("Bonus or split", r"bonus|split|sub.division"),
    ("Earnings call", r"earnings call|conference call|analyst.*call"),
    ("Shareholder meeting", r"annual general meeting|\bagm\b|extra.?ordinary general meeting|\begm\b"),
]


def _month(tok):
    t = tok.lower().rstrip(".")
    if t == "sept":
        t = "sep"
    return MONTHS.get(t) or next((v for k, v in MONTHS.items() if k[:3] == t), None)


def find_dates(text):
    out = []
    for pat, kind in DATE_PATTERNS:
        for m in pat.finditer(text or ""):
            try:
                if kind == "mdy":
                    d = date(int(m.group(3)), _month(m.group(1)), int(m.group(2)))
                elif kind == "dmy":
                    d = date(int(m.group(3)), _month(m.group(2)), int(m.group(1)))
                else:
                    d = date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except (TypeError, ValueError):
                continue
            out.append((d, m.start()))
    return out


def purpose(text):
    found = [label for label, pat in PURPOSES if re.search(pat, text or "", re.I)]
    return ", ".join(found) or "Board meeting"


def upcoming_from_filing(title, body, published, today=None, horizon_days=120):
    """Future dates named in a board-meeting or record-date notice."""
    text = f"{title}. {body or ''}"
    if not NOTICE.search(text):
        return []
    today = today or now_utc().astimezone(IST).date()
    pub = published.astimezone(IST).date() if isinstance(published, datetime) else today
    seen, out = set(), []
    for sentence in re.split(r"(?<=[.;])\s+", text):
        if not EVENT_SENTENCE.search(sentence):
            continue
        for d, pos in find_dates(sentence):
            if NOT_EVENT_DATE.search(sentence[max(0, pos - 40):pos]):
                continue        # "quarter ended 31.12.2026", "window closed from 01/01/2027"
            if d < today or d < pub or d > today + timedelta(days=horizon_days) or d in seen:
                continue
            seen.add(d)
            out.append({"date": d.isoformat(), "what": purpose(text)})
    return sorted(out, key=lambda x: x["date"])
