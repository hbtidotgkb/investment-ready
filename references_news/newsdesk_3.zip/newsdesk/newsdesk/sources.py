"""Fetchers. Each returns a list of RawItem; none of them touch the database."""
import html
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

import requests

from .clock import IST, now_utc

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
TIMEOUT = 20


@dataclass
class RawItem:
    source_id: str
    url: str
    title: str
    body: str
    published_at: datetime
    category: str | None = None
    scrip: str | None = None      # BSE scrip code when the source gives it
    is_stub: bool = False         # headline/teaser only, full text pending
    tickers: tuple = ()           # tickers the source itself tagged (e.g. TradingView symbols)


def clean_text(s):
    s = re.sub(r"<[^>]+>", " ", s or "")
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


def _parse_date(s):
    if not s:
        return now_utc()
    s = s.strip()
    try:
        d = parsedate_to_datetime(s)
    except (TypeError, ValueError):
        try:
            d = datetime.fromisoformat(s.replace("Z", "+00:00"))
        except ValueError:
            return now_utc()
    if d.tzinfo is None:
        d = d.replace(tzinfo=IST)
    return d.astimezone(timezone.utc)


def parse_feed(source_id, xml_text, stub=False):
    """RSS 2.0 or Atom."""
    root = ET.fromstring(xml_text)
    items = []
    atom = "{http://www.w3.org/2005/Atom}"
    for it in root.iter("item"):
        link = (it.findtext("link") or "").strip()
        if not link:
            continue
        items.append(RawItem(
            source_id, link, clean_text(it.findtext("title")),
            clean_text(it.findtext("description")),
            _parse_date(it.findtext("pubDate") or it.findtext("{http://purl.org/dc/elements/1.1/}date")),
            category=clean_text(it.findtext("category")) or None, is_stub=stub))
    for it in root.iter(f"{atom}entry"):
        link_el = it.find(f"{atom}link")
        link = link_el.get("href") if link_el is not None else ""
        if not link:
            continue
        items.append(RawItem(
            source_id, link, clean_text(it.findtext(f"{atom}title")),
            clean_text(it.findtext(f"{atom}summary") or it.findtext(f"{atom}content")),
            _parse_date(it.findtext(f"{atom}updated") or it.findtext(f"{atom}published")),
            is_stub=stub))
    return items


def fetch_rss(src, **_):
    r = requests.get(src["url"], headers={"User-Agent": UA}, timeout=TIMEOUT)
    r.raise_for_status()
    return parse_feed(src["id"], r.content, stub=bool(src.get("stub")))


BSE_API = "https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w"
BSE_ATTACH = "https://www.bseindia.com/xml-data/corpfiling/AttachLive/"


def parse_bse_rows(source_id, rows):
    items = []
    for row in rows:
        att = (row.get("ATTACHMENTNAME") or "").strip()
        news_id = row.get("NEWSID") or ""
        url = BSE_ATTACH + att if att else f"https://www.bseindia.com/corporates/ann.html#{news_id}"
        company = (row.get("SLONGNAME") or "").strip()
        subject = clean_text(row.get("NEWSSUB") or row.get("HEADLINE"))
        body = clean_text(row.get("HEADLINE") or "")
        dt = row.get("DT_TM") or row.get("NEWS_DT")
        items.append(RawItem(
            source_id, url, f"{company}: {subject}" if company else subject,
            body if body != subject else "", _parse_date(dt),
            category=row.get("CATEGORYNAME"), scrip=str(row.get("SCRIP_CD") or "") or None))
    return items


def fetch_bse(src, scrip=None, days=1):
    """Corporate announcements. With scrip, only that company (on-demand path)."""
    today = now_utc().astimezone(IST)
    prev = today - timedelta(days=days)
    headers = {"User-Agent": UA, "Referer": "https://www.bseindia.com/",
               "Origin": "https://www.bseindia.com", "Accept": "application/json"}
    items = []
    for page in range(1, int(src.get("pages", 3)) + 1):
        params = {"pageno": page, "strCat": "-1", "strPrevDate": prev.strftime("%Y%m%d"),
                  "strScrip": scrip or "", "strSearch": "P", "strToDate": today.strftime("%Y%m%d"),
                  "strType": "C", "subcategory": "-1"}
        r = requests.get(BSE_API, params=params, headers=headers, timeout=TIMEOUT)
        r.raise_for_status()
        rows = (r.json() or {}).get("Table") or []
        if not rows:
            break
        items.extend(parse_bse_rows(src["id"], rows))
    return items


def pdf_text(url, max_pages=6, max_chars=20000, max_bytes=8_000_000):
    """Text of a filing's PDF attachment, so its figures can be checked against the press.
    Returns "" when the file is too big, unreadable, or pypdf isn't installed."""
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""
    import io
    r = requests.get(url, headers={"User-Agent": UA, "Referer": "https://www.bseindia.com/"},
                     timeout=TIMEOUT, stream=True)
    r.raise_for_status()
    data = r.raw.read(max_bytes + 1, decode_content=True)
    if len(data) > max_bytes:
        return ""
    reader = PdfReader(io.BytesIO(data))
    parts = []
    for page in reader.pages[:max_pages]:
        parts.append(page.extract_text() or "")
        if sum(map(len, parts)) >= max_chars:
            break
    return clean_text(" ".join(parts))[:max_chars]


GNEWS = "https://news.google.com/rss/search"


def parse_gnews(xml_text, publishers, default_source):
    """Google News search results. Each item names its publisher in <source>;
    that decides which of our sources (and so which tier and trust) it counts as."""
    pub_map = {k.lower(): v for k, v in (publishers or {}).items()}
    root = ET.fromstring(xml_text)
    items = []
    for it in root.iter("item"):
        link = (it.findtext("link") or "").strip()
        pub = clean_text(it.findtext("source"))
        title = clean_text(it.findtext("title"))
        if pub and title.endswith(f" - {pub}"):
            title = title[: -len(pub) - 3]
        if not link or not title:
            continue
        sid = pub_map.get(pub.lower(), default_source)
        items.append(RawItem(sid, link, title, "", _parse_date(it.findtext("pubDate")),
                             category=pub or None))
    return items


def search_query(aliases, days):
    names = " OR ".join(f'"{a}"' for a in aliases)
    return f"({names}) when:{days}d"


def fetch_gnews(src, aliases=(), days=7):
    params = {"q": search_query(aliases, days), "hl": "en-IN", "gl": "IN", "ceid": "IN:en"}
    r = requests.get(GNEWS, params=params, headers={"User-Agent": UA}, timeout=TIMEOUT)
    r.raise_for_status()
    return parse_gnews(r.content, src.get("publishers"), src.get("default_source", "web_other"))


FETCHERS = {"rss": fetch_rss, "bse": fetch_bse, "gnews": fetch_gnews}


def fetch(src, **kw):
    return FETCHERS[src["kind"]](src, **kw)
