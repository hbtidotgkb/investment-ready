const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

(async () => {
  const s = await chrome.storage.local.get(["server", "token", "history"]);
  $("#server").value = s.server || "http://127.0.0.1:8765";
  $("#token").value = s.token || "";
  const h = s.history || [];
  $("#history").innerHTML = h.length
    ? h.map((e) => `<li><div class="t">${esc(e.title)}</div>
        <div class="${e.status}">${{ sent: "Sent", failed: "Not sent", skipped: "Skipped" }[e.status]}</div>
        <div class="d">${esc(e.detail)}</div></li>`).join("")
    : `<li class="d">Open an ET Prime article and it will appear here once it’s sent.</li>`;
})();

$("#now").onclick = async () => {
  const out = $("#now-result");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { type: "capture_now" });
    out.className = r.status === "sent" ? "sent" : "skipped";
    out.textContent = r.status === "sent"
      ? `Sent ${r.chars.toLocaleString()} characters (found via ${r.how}).`
      : `Found only ${r.chars} characters (${r.how}). Scroll through the article once, then try again.`;
  } catch {
    out.className = "failed";
    out.textContent = "Open an ET Prime article in this tab first, then try again.";
  }
};

$("#save").onclick = async () => {
  await chrome.storage.local.set({ server: $("#server").value.trim(), token: $("#token").value.trim() });
  $("#saved").textContent = "Saved";
};
