"""News brain: turns a Newsdesk dossier into a cited news view for the Head CA.

  python news_brain.py RELIANCE                 # Claude, default settings
  python news_brain.py RELIANCE --brain openai  # or gemini
  python news_brain.py BSE --days 90 --no-refresh
  python news_brain.py RELIANCE --dry-run       # print the prompts, call no model

Two passes:
  1. Scan: the brain reads the dossier and names up to 5 citations it wants in full.
  2. Read: those articles' saved text is added, and the brain writes its view.
Then the critic (plain code, no model) checks every citation and figure.

Needs: requests. Keys come from the environment:
  ANTHROPIC_API_KEY, OPENAI_API_KEY + OPENAI_MODEL, GEMINI_API_KEY + GEMINI_MODEL
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import requests

NEWSDESK = os.environ.get("NEWSDESK_URL", "http://127.0.0.1:8765")
OUT_DIR = Path(os.environ.get("NEWS_BRAIN_OUT", "data/brain_views"))
MAX_READ = 5
ARTICLE_CHARS = 6000

RULES = """You are the news analyst for an Indian equity research desk. You get a news
dossier for one stock, built from exchange filings and the financial press.

Rules:
- Use only facts in the dossier and the attached articles. Cite every point with its [n].
- Weigh evidence by status: filed and confirmed are strong; unconfirmed, speculation
  and opinion are weak; denied and contradicted claims count against the report.
- Analyst targets and ratings are opinion, not news. Never use one as a driver.
- Share-price moves are context for "already priced in", not drivers.
- Items under "Coming up" are catalysts that have not happened yet.
- Say what the dossier doesn't tell you. Don't fill gaps from memory."""

SCAN = RULES + """

First pass. Read the dossier and choose up to {n} citation numbers whose full text you
need to judge this stock: prefer filings and ET Prime articles, then the most material
events. Return JSON only: {{"read": [n, ...], "why": "one sentence"}}

<dossier>
{dossier}
</dossier>"""

VIEW = RULES + """

Write the news view. Return JSON only, with exactly these keys:
{{
  "stance": "positive | negative | neutral | mixed",
  "strength": 0.0-1.0,
  "horizon": "days | weeks | months",
  "drivers": [{{"point": "...", "direction": "+ or -", "citations": [n]}}],
  "risks": [{{"point": "...", "citations": [n]}}],
  "catalysts": [{{"date": "YYYY-MM-DD", "what": "...", "citations": [n]}}],
  "already_priced_in": "yes | partly | no | unknown, with a short reason",
  "would_change_my_view": ["..."],
  "gaps": ["..."]
}}

<dossier>
{dossier}
</dossier>

<full_articles>
{articles}
</full_articles>"""


# --- model calls -----------------------------------------------------------

def call_claude(prompt):
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
    r = requests.post("https://api.anthropic.com/v1/messages", timeout=120, headers={
        "x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01",
        "content-type": "application/json"},
        json={"model": model, "max_tokens": 2000, "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    return "".join(b.get("text", "") for b in r.json()["content"])


def call_openai(prompt):
    r = requests.post("https://api.openai.com/v1/chat/completions", timeout=120, headers={
        "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
        json={"model": os.environ["OPENAI_MODEL"], "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def call_gemini(prompt):
    model = os.environ["GEMINI_MODEL"]
    r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                      params={"key": os.environ["GEMINI_API_KEY"]}, timeout=120,
                      json={"contents": [{"parts": [{"text": prompt}]}]})
    r.raise_for_status()
    return "".join(p.get("text", "") for p in r.json()["candidates"][0]["content"]["parts"])


BRAINS = {"claude": call_claude, "openai": call_openai, "gemini": call_gemini}


def parse_json(text):
    text = re.sub(r"```(json)?", "", text).strip()
    start, end = text.find("{"), text.rfind("}")
    return json.loads(text[start:end + 1])


# --- Newsdesk --------------------------------------------------------------

def get_dossier(ticker, days, refresh):
    q = {"days": days, "refresh": "auto" if refresh else "no"}
    base = f"{NEWSDESK}/api/dossier/{ticker}"
    d = requests.get(base, params=q, timeout=180).json()
    if "error" in d:
        sys.exit(d["error"])
    md = requests.get(base, params={**q, "refresh": "no", "format": "md"}, timeout=60).text
    return d, md


def full_articles(dossier, numbers):
    parts = []
    for n in numbers[:MAX_READ]:
        c = dossier["citations"].get(str(n))
        if not c:
            continue
        a = requests.get(f"{NEWSDESK}/api/article/{c['article_id']}", timeout=30).json()
        text = (a.get("body") or "").strip() or "(only the headline was saved)"
        parts.append(f"[{n}] {c['source']} (tier {c['tier']}), {c['published_at']}\n"
                     f"{c['title']}\n{text[:ARTICLE_CHARS]}")
    return "\n\n---\n\n".join(parts) or "(none requested)"


# --- critic ----------------------------------------------------------------

WEAK = {"opinion"}
AGAINST = {"denied", "contradicted"}
NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def critic(view, dossier, article_text=""):
    """Mechanical checks. Returns a list of problems; empty means the view passes."""
    problems = []
    cites = dossier["citations"]
    by_cite = {}
    for e in dossier["events"]:
        for n in e["citations"]:
            by_cite.setdefault(n, e)
    texts = {n: f"{c['title']} {c['quote']}" for n, c in cites.items()}

    def check(section, item):
        refs = item.get("citations") or []
        if not refs:
            problems.append(f"{section}: no citation for “{item.get('point') or item.get('what')}”")
            return
        missing = [n for n in refs if str(n) not in cites]
        if missing:
            problems.append(f"{section}: cites {missing}, which aren't in the dossier")
            return
        evs = [by_cite.get(n) for n in refs if by_cite.get(n)]
        if section == "drivers":
            if evs and all(e["fact_type"] in WEAK for e in evs):
                problems.append(f"drivers: “{item['point']}” rests only on opinion")
            if any(e["validation"] in AGAINST for e in evs):
                problems.append(f"drivers: “{item['point']}” uses a report that a filing denied or contradicted")
        claim_text = " ".join(texts[str(n)] for n in refs) + " " + " ".join(
            c["text"] for e in evs for c in e["claims"]) + " " + article_text
        flat = claim_text.replace(",", "")
        for num in NUM.findall(item.get("point") or ""):
            plain = num.replace(",", "")
            if len(plain) >= 2 and plain not in flat:
                problems.append(f"{section}: figure {num} in “{item['point']}” isn't in the cited text")

    for section in ("drivers", "risks", "catalysts"):
        for item in view.get(section) or []:
            check(section, item)
    if view.get("stance") not in ("positive", "negative", "neutral", "mixed"):
        problems.append("stance must be positive, negative, neutral or mixed")
    return problems


# --- run -------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ticker")
    ap.add_argument("--brain", choices=BRAINS, default="claude")
    ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--no-refresh", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="print the prompts; call no model")
    a = ap.parse_args()
    ticker = a.ticker.upper()

    dossier, md = get_dossier(ticker, a.days, not a.no_refresh)
    scan_prompt = SCAN.format(n=MAX_READ, dossier=md)
    if a.dry_run:
        print(scan_prompt)
        print("\n===== second pass (with the first", MAX_READ, "citations as an example) =====\n")
        print(VIEW.format(dossier="(same dossier)",
                          articles=full_articles(dossier, list(range(1, MAX_READ + 1)))))
        return

    call = BRAINS[a.brain]
    wanted = parse_json(call(scan_prompt)).get("read") or []
    articles = full_articles(dossier, [int(n) for n in wanted])
    view = parse_json(call(VIEW.format(dossier=md, articles=articles)))
    problems = critic(view, dossier, articles)

    record = {"ticker": ticker, "brain": a.brain, "created_at": datetime.now(timezone.utc).isoformat(),
              "dossier_as_of": dossier["as_of"], "read_in_full": wanted,
              "view": view, "critic": {"passed": not problems, "problems": problems}}
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / f"{ticker}-{a.brain}-{datetime.now():%Y%m%d-%H%M%S}.json"
    path.write_text(json.dumps(record, indent=2, ensure_ascii=False))
    print(json.dumps(record, indent=2, ensure_ascii=False))
    print(f"\nSaved to {path}", file=sys.stderr)
    sys.exit(0 if not problems else 2)


if __name__ == "__main__":
    main()
