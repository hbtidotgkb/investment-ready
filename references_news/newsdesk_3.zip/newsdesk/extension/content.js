// Runs on ET Prime pages you open. Reads the article you can already see
// and hands it to the background worker. It never opens pages on its own.
(() => {
  const MIN_CHARS = 600;   // shorter usually means the paywall or page hasn't loaded
  const TRIES = [1500, 4000, 8000, 15000];
  let sentFor = null;

  const meta = (name) =>
    document.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.content || "";
  const clean = (s) => (s || "").replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").trim();

  // Text of an element, one line per block, without scripts, menus or ads.
  function blockText(el) {
    const copy = el.cloneNode(true);
    copy.querySelectorAll("script, style, noscript, iframe, svg, button, nav, aside, figure, form, " +
      "[class*='share'], [class*='social'], [class*='related'], [class*='advert'], [class*='ad-'], " +
      "[class*='newsletter'], [class*='comment'], [id*='taboola']").forEach((n) => n.remove());
    const lines = (copy.innerText || copy.textContent || "").split(/\n+/).map(clean);
    return lines.filter((t) => t.length > 40).join("\n\n");
  }

  // 1. Article body marked up for search engines.
  function fromSchema() {
    const el = document.querySelector("[itemprop='articleBody'], [data-articlebody], [class*='articleBody']");
    return el ? { text: blockText(el), how: "articleBody element" } : null;
  }

  // 2. The JSON-LD block many news sites embed (may be shorter than the page).
  function fromJsonLd() {
    let best = "";
    for (const s of document.querySelectorAll("script[type='application/ld+json']")) {
      try {
        const walk = (o) => {
          if (!o || typeof o !== "object") return;
          if (Array.isArray(o)) return o.forEach(walk);
          if (typeof o.articleBody === "string" && o.articleBody.length > best.length) best = o.articleBody;
          Object.values(o).forEach(walk);
        };
        walk(JSON.parse(s.textContent));
      } catch { /* not JSON we can read */ }
    }
    return best ? { text: clean(best), how: "page metadata" } : null;
  }

  // 3. Readability-style: credit each paragraph's text to its parent and grandparent,
  //    then take the container that collects the most prose. A single block of
  //    text separated by <br> scores on its own.
  function fromDensity() {
    const score = new Map();
    const blocks = document.querySelectorAll("p, div, section, li, span");
    for (const b of blocks) {
      if (b.querySelector("p, div, section")) continue;        // leaf text blocks only
      const t = clean(b.innerText || "");
      if (t.length < 60) continue;
      const links = [...b.querySelectorAll("a")].reduce((n, a) => n + (a.innerText || "").length, 0);
      if (links / t.length > 0.4) continue;                    // menus, link lists
      // the block itself, then parent and grandparent at falling weight
      let up = b, w = 1;
      for (let i = 0; i < 3 && up && up !== document.body; i++, w /= 2, up = up.parentElement) {
        score.set(up, (score.get(up) || 0) + t.length * w);
      }
    }
    let best = null, bestScore = 0;
    for (const [el, s] of score) if (s > bestScore) { best = el; bestScore = s; }
    return best ? { text: blockText(best), how: "densest text block" } : null;
  }

  function extract() {
    const found = [fromSchema(), fromDensity(), fromJsonLd()].filter((r) => r && r.text);
    found.sort((a, b) => b.text.length - a.text.length);
    return found[0] || { text: "", how: "nothing found" };
  }

  function capture({ force = false, last = false } = {}) {
    const url = location.href.split("#")[0].split("?")[0];
    const title = clean(document.querySelector("h1")?.innerText) || meta("og:title") || document.title;
    if (sentFor === url && !force) return { status: "already sent" };
    const { text, how } = extract();
    if (text.length < MIN_CHARS) {
      if (last || force) chrome.runtime.sendMessage({ type: "too_short", url, title, chars: text.length, how });
      return { status: "too short", chars: text.length, how };
    }
    sentFor = url;
    chrome.runtime.sendMessage({
      type: "capture", url, title, body: text,
      published_at: meta("article:published_time") || meta("og:updated_time") || null,
    });
    return { status: "sent", chars: text.length, how };
  }

  // Wait for lazy-loaded text, then try again a few times; also catch in-page navigation.
  TRIES.forEach((ms, i) => setTimeout(() => capture({ last: i === TRIES.length - 1 }), ms));
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href; sentFor = null;
      TRIES.forEach((ms, i) => setTimeout(() => capture({ last: i === TRIES.length - 1 }), ms));
    }
  }, 1000);

  // "Capture this page" button in the popup.
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg.type === "capture_now") reply(capture({ force: true }));
  });
})();
