import sqlite3
import threading

from .config import DB_PATH

WRITE_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources(
  id TEXT PRIMARY KEY, name TEXT, tier INTEGER, trust REAL, base_trust REAL, kind TEXT,
  last_run TEXT, last_ok TEXT, last_error TEXT, items_total INTEGER DEFAULT 0,
  confirmed INTEGER DEFAULT 0, contradicted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS watchlist(
  ticker TEXT PRIMARY KEY, name TEXT, bse_scrip TEXT, aliases TEXT, exclude TEXT,
  market_cap_cr REAL);
CREATE TABLE IF NOT EXISTS articles(
  id INTEGER PRIMARY KEY, source_id TEXT, url TEXT UNIQUE, title TEXT, body TEXT,
  published_at TEXT, fetched_at TEXT, content_hash TEXT, is_stub INTEGER DEFAULT 0,
  category TEXT, scrip TEXT, direction TEXT, dropped_reason TEXT);
CREATE TABLE IF NOT EXISTS article_tickers(
  article_id INTEGER, ticker TEXT, salience REAL, PRIMARY KEY(article_id, ticker));
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY, ticker TEXT, event_type TEXT, title TEXT, summary TEXT,
  direction TEXT, fact_type TEXT, amount_cr REAL, sig TEXT, validation TEXT,
  materiality REAL, confidence REAL, recency REAL, score REAL,
  first_seen TEXT, last_updated TEXT);
CREATE TABLE IF NOT EXISTS event_articles(
  event_id INTEGER, article_id INTEGER, PRIMARY KEY(event_id, article_id));
CREATE TABLE IF NOT EXISTS claims(
  id INTEGER PRIMARY KEY, event_id INTEGER, article_id INTEGER, text TEXT,
  amount_cr REAL, status TEXT, basis_article_id INTEGER);
CREATE TABLE IF NOT EXISTS ticker_state(ticker TEXT PRIMARY KEY, last_ingest TEXT);
CREATE TABLE IF NOT EXISTS dossier_cache(ticker TEXT PRIMARY KEY, built_at TEXT, json TEXT);
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY, ticker TEXT, event_id INTEGER, kind TEXT, message TEXT,
  created_at TEXT, seen INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS jobs(name TEXT PRIMARY KEY, last_run TEXT);
CREATE INDEX IF NOT EXISTS ix_events_ticker ON events(ticker, last_updated);
CREATE INDEX IF NOT EXISTS ix_at_ticker ON article_tickers(ticker);
"""


MIGRATIONS = ["ALTER TABLE articles ADD COLUMN hint_tickers TEXT",
              "ALTER TABLE watchlist ADD COLUMN link_only TEXT",
              "ALTER TABLE watchlist ADD COLUMN related TEXT"]


def connect(path=None):
    p = path or DB_PATH
    if str(p) != ":memory:":
        p = str(p)
        import os
        os.makedirs(os.path.dirname(p), exist_ok=True)
    conn = sqlite3.connect(p, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA)
    for m in MIGRATIONS:       # columns added after the first release
        try:
            conn.execute(m)
        except sqlite3.OperationalError:
            pass
    return conn
