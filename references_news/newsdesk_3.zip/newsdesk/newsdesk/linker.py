"""Entity linking: which watchlist stocks is this article about, and how centrally."""
import json
import re

RELATED_SALIENCE = 0.4     # a subsidiary or asset in the headline: relevant, not the subject


def _pattern(name):
    flags = 0 if (len(name) <= 4 and name.isupper()) else re.IGNORECASE
    return re.compile(rf"(?<![\w&]){re.escape(name)}(?![\w&])", flags)


class Linker:
    """aliases: names that identify the company (also used for news search).
    link_only: shorter names the press uses that are too broad to search for,
    such as "Reliance"; safe only together with exclude.
    related: subsidiaries, brands and assets ("Jio", "Jamnagar refinery").
    exclude: look-alike names, removed before matching."""

    def __init__(self, stocks):
        self.stocks = []
        self.by_scrip = {}
        for s in stocks:
            names = (s.get("aliases") or [s["name"]]) + (s.get("link_only") or [])
            pats = [_pattern(a) for a in names]
            rel = [_pattern(a) for a in (s.get("related") or [])]
            # longest first, so "Reliance Power Ltd" is removed before "Reliance Power"
            excl = [re.compile(re.escape(e), re.IGNORECASE)
                    for e in sorted(s.get("exclude") or [], key=len, reverse=True)]
            self.stocks.append((s["ticker"], pats, rel, excl))
            if s.get("bse_scrip"):
                self.by_scrip[str(s["bse_scrip"])] = s["ticker"]

    @classmethod
    def from_db(cls, conn):
        rows = conn.execute("SELECT * FROM watchlist").fetchall()
        load = lambda r, k: json.loads(r[k] or "[]") if k in r.keys() else []
        return cls([{**dict(r), "aliases": load(r, "aliases"), "exclude": load(r, "exclude"),
                     "link_only": load(r, "link_only"), "related": load(r, "related")} for r in rows])

    def link(self, title, body, scrip=None, min_salience=0.3, tickers=()):
        """Returns {ticker: salience}. Salience 1.0 = the article is about this company.
        tickers: symbols the source tagged itself; trusted like a BSE scrip code."""
        out = {}
        known = {t for t, _, _, _ in self.stocks}
        for t in tickers or ():
            if t in known:
                out[t] = 1.0
        if scrip and scrip in self.by_scrip:
            out[self.by_scrip[scrip]] = 1.0
        lead, rest = (body or "")[:400], (body or "")[400:]
        for ticker, pats, rel, excl in self.stocks:
            if ticker in out:
                continue
            t, l, r = title or "", lead, rest
            for e in excl:                       # blank out look-alike names first
                t, l, r = e.sub(" ", t), e.sub(" ", l), e.sub(" ", r)
            hits_t = sum(len(p.findall(t)) for p in pats)
            hits_l = sum(len(p.findall(l)) for p in pats)
            hits_r = sum(len(p.findall(r)) for p in pats)
            sal = min(1.0, 0.6 * min(hits_t, 1) + 0.2 * min(hits_l, 2) + 0.05 * min(hits_r, 4))
            if sal < min_salience and any(p.search(t) or p.search(l) for p in rel):
                sal = RELATED_SALIENCE
            if sal >= min_salience:
                out[ticker] = round(sal, 2)
        return out
