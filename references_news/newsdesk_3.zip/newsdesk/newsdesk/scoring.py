"""Clustering similarity, validation of claims against filings, and event scoring."""
import re
from .clock import now_utc, parse_iso
from .enrich import EVENT_TYPES

STOP = set("""a an the of to in on for and or by with from at as is are was were be been this that
its it their his her has have had will would can could into over after before than about up down
said says say new also more most per cent crore cr rs inr stock stocks share shares company ltd
limited india indian today market markets""".split())


def tokens(text, drop=()):
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    drop = {w for d in drop for w in re.findall(r"[a-z0-9]+", d.lower())}
    return {w for w in words if len(w) > 2 and w not in STOP and w not in drop
            and not (w.isdigit() and len(w) <= 3)}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def similarity(a, b):
    """Headlines about one event share few words, so blend Jaccard with overlap
    (shared / smaller set), counted only when at least two words are shared."""
    if not a or not b:
        return 0.0
    shared = len(a & b)
    overlap = shared / min(len(a), len(b)) if shared >= 2 else 0.0
    return max(jaccard(a, b), 0.8 * overlap)


def amounts_close(a, b, tol=0.05):
    return a and b and abs(a - b) / max(a, b) <= tol


# --- validation -----------------------------------------------------------

DENIAL = re.compile(r"denies|no such|not aware|speculative|baseless|no (proposal|decision)|"
                    r"factually incorrect|no information|not true|rumou?r", re.IGNORECASE)


def validate_event(conn, event_id):
    """Sets claim statuses and the event's validation label. Returns the label."""
    rows = conn.execute("""
        SELECT a.id, a.title, a.body, s.tier, e.event_type FROM event_articles ea
        JOIN articles a ON a.id = ea.article_id JOIN sources s ON s.id = a.source_id
        JOIN events e ON e.id = ea.event_id WHERE ea.event_id = ?""", (event_id,)).fetchall()
    if not rows:
        return "unconfirmed"
    etype = rows[0]["event_type"]
    filings = [r for r in rows if r["tier"] == 0]
    press_ids = {r["id"] for r in rows if r["tier"] > 0}

    filing_amounts = []
    for f in filings:
        for c in conn.execute("SELECT amount_cr FROM claims WHERE event_id=? AND article_id=?",
                              (event_id, f["id"])):
            if c["amount_cr"]:
                filing_amounts.append((c["amount_cr"], f["id"]))

    denial = next((f for f in filings if DENIAL.search(f"{f['title']} {f['body']}")), None)

    any_contradicted = any_confirmed = False
    for c in conn.execute("SELECT * FROM claims WHERE event_id=?", (event_id,)).fetchall():
        if c["article_id"] not in press_ids:
            status, basis = "filed", c["article_id"]
        elif denial is not None:
            status, basis = "denied", denial["id"]
        elif c["amount_cr"] and filing_amounts:
            match = next((fid for amt, fid in filing_amounts if amounts_close(amt, c["amount_cr"])), None)
            status, basis = ("confirmed", match) if match else ("contradicted", filing_amounts[0][1])
        elif filings:
            status, basis = "confirmed", filings[0]["id"]
        else:
            status, basis = "unconfirmed", None
        any_contradicted |= status in ("contradicted", "denied")
        any_confirmed |= status == "confirmed"
        if status != c["status"] and status in ("confirmed", "contradicted", "denied"):
            col = "confirmed" if status == "confirmed" else "contradicted"
            conn.execute(f"""UPDATE sources SET {col} = {col} + 1 WHERE id =
                (SELECT source_id FROM articles WHERE id=?)""", (c["article_id"],))
        conn.execute("UPDATE claims SET status=?, basis_article_id=? WHERE id=?", (status, basis, c["id"]))

    if denial is not None and press_ids:
        label = "denied"
    elif any_contradicted:
        label = "contradicted"
    elif filings:
        label = "confirmed" if press_ids else "filed"
    elif etype in ("governance_flag", "accounting_concern"):
        label = "investigative"
    else:
        label = "unconfirmed"
    conn.execute("UPDATE events SET validation=? WHERE id=?", (label, event_id))
    return label


# --- scoring --------------------------------------------------------------

def score_event(conn, event_id, now=None):
    now = now or now_utc()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
    srcs = conn.execute("""
        SELECT DISTINCT s.id, s.trust FROM event_articles ea JOIN articles a ON a.id = ea.article_id
        JOIN sources s ON s.id = a.source_id WHERE ea.event_id=? AND a.dropped_reason IS NULL""",
        (event_id,)).fetchall()
    stub_only = conn.execute("""SELECT MIN(a.is_stub) m FROM event_articles ea JOIN articles a
        ON a.id = ea.article_id WHERE ea.event_id=?""", (event_id,)).fetchone()["m"]

    miss = 1.0
    for s in srcs:
        miss *= 1 - (s["trust"] or 0.5)
    conf = 1 - miss
    v = ev["validation"]
    conf = {"filed": max(conf, 0.97), "confirmed": max(conf, 0.9), "denied": conf * 0.25,
            "contradicted": conf * 0.4, "unconfirmed": min(conf, 0.75),
            "investigative": min(conf, 0.8)}.get(v, conf)
    if ev["fact_type"] == "speculation" and v not in ("filed", "confirmed"):
        conf *= 0.7
    if ev["fact_type"] == "opinion":
        conf *= 0.6
    if stub_only:
        conf *= 0.8

    base, half_life, _ = EVENT_TYPES.get(ev["event_type"], EVENT_TYPES["other"])
    mat = base
    if ev["amount_cr"]:
        mcap = conn.execute("SELECT market_cap_cr FROM watchlist WHERE ticker=?",
                            (ev["ticker"],)).fetchone()
        if mcap and mcap["market_cap_cr"]:
            mat += min(0.3, 3 * ev["amount_cr"] / mcap["market_cap_cr"])
        elif ev["amount_cr"] >= 1000:
            mat += 0.1
    mat = min(1.0, mat)

    age_h = max(0.0, (now - parse_iso(ev["first_seen"])).total_seconds() / 3600)
    recency = 0.5 ** (age_h / half_life)
    novelty = 1.0     # hook: scale down when price already moved since first_seen (needs Kite)
    score = mat * conf * recency * novelty
    conn.execute("UPDATE events SET materiality=?, confidence=?, recency=?, score=? WHERE id=?",
                 (round(mat, 3), round(conf, 3), round(recency, 3), round(score, 4), event_id))
    return score


def recalibrate_trust(conn):
    """Nightly: move each press source's trust toward its observed accuracy."""
    for s in conn.execute("SELECT * FROM sources WHERE tier > 0").fetchall():
        prior = 20
        trust = (s["base_trust"] * prior + s["confirmed"]) / (prior + s["confirmed"] + s["contradicted"])
        conn.execute("UPDATE sources SET trust=? WHERE id=?", (round(trust, 3), s["id"]))
