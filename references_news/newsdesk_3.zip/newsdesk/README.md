# Newsdesk

Collects stock news from filings and the financial press, checks press claims
against exchange filings, scores each event, and serves a cited dossier per stock
for the news brain. It includes a local UI where you can see every claim and its sources.

Only `requests` and `pyyaml` are needed. Everything else is Python's standard library.

## Run

```
python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
python run.py serve          # UI at http://127.0.0.1:8765, async worker running
```

Other commands:

| Command | What it does |
|---|---|
| `python run.py serve --no-worker` | UI and API only; on-demand fetching still works |
| `python run.py fetch` | Poll every source once and exit |
| `python run.py dossier LT --md` | Print a dossier (fetches first if data is stale) |
| `python run.py nightly` | Run the nightly re-score and trust update now |
| `python run.py check RELIANCE` | Test every source for one stock: what came back, what matched, what failed |
| `python -m unittest discover tests` | Offline tests, including the HTTP server |

Data is stored in `data/newsdesk.db` (SQLite). Set `NEWSDESK_DB` to put it elsewhere.

## How async and on-demand fit together

**Async (the worker thread).** Every 30 seconds it checks which sources are due.
How often a source is polled depends on the market phase (IST), set per source in
`config/sources.yaml`: overnight, premarket (07:00–09:15), market (09:15–15:30)
and postmarket (15:30–22:00). It also runs three fixed jobs:
- 07:00: sweep every source
- 08:45: sweep again, then pre-build every watchlist dossier
- 23:00: nightly maintenance: decay scores, re-check unconfirmed claims against
  the day's filings, update source trust

When a poll changes events for a stock, that stock's dossier is rebuilt straight away.

**On demand.** `GET /api/dossier/LT` first checks how fresh LT's data is. If it is
older than the freshness limit (2 min in market hours, 30 min otherwise), it pulls
LT's BSE filings by scrip code, searches the news for LT by name, and runs one pass
over the feeds, then builds the dossier.

The RSS feeds only hold the latest market-wide headlines, so they rarely have
anything about one particular stock. The company search (Google News) is what finds
a stock's recent news. Each result is credited to its real publisher (Mint,
Business Standard and so on), so tier and trust come from that outlet. Outlets not
in the publisher list count as "Other outlets" (tier 2).
- `?refresh=force` fetches regardless
- `?refresh=no` builds from what is stored

## For the brain

- `GET /api/dossier/LT`: JSON with ranked events, claims and their status
  (filed / confirmed / unconfirmed / contradicted / denied), conflicts,
  open questions, and numbered citations (source, tier, URL, times, SHA-256 of
  the saved text).
- `GET /api/dossier/LT?format=md`: the same as compact text, with a [n] on every
  line and the citation list at the end. This is what "Copy for brain" puts on the clipboard.

Give the same dossier to every brain. Your Critic CA can reject any claim in a brain's
output that doesn't carry a [n] pointing into the dossier.

## ET Prime capture (Chrome extension in `extension/`)

The worker only sees ET Prime headlines from the feed. The extension adds the full
text of the articles you open.

Install it:
1. Open `chrome://extensions` and turn on Developer mode (top right).
2. Click "Load unpacked" and pick the `extension` folder.
3. If Newsdesk runs somewhere other than http://127.0.0.1:8765, or you set
   `NEWSDESK_INGEST_TOKEN`, click the extension icon and enter the address and token.

Use it: open any ET Prime article while logged in. After a few seconds, the toolbar
icon shows the result:
- ✓ sent
- ! Newsdesk not reachable
- ? too little text visible (usually not logged in)

The popup lists the last 25 articles and which stocks each one linked to.
The extension only reads pages you open; it never fetches anything by itself.

TradingView isn't captured. Its terms don't allow storing its data, so use the
TradingView MCP in Claude on demand instead.

Headline batches go to `POST /api/ingest/batch` with
`{"items": [{"url", "title", "provider", "symbols": ["NSE:RELIANCE"], "published_at"}]}`.

To post a full article from something else, such as your stocknews module, send:

```
POST http://127.0.0.1:8765/api/ingest
Content-Type: application/json
X-Ingest-Token: <only if NEWSDESK_INGEST_TOKEN is set>

{"url": "...", "title": "...", "body": "<article text>", "published_at": "2026-11-20T10:00:00+05:30"}
```

## What the dossier is built from

| Source | What it gives | Tier |
|---|---|---|
| BSE announcements | Every filing, with the attached PDF read for its figures (watchlist stocks only) | 0 |
| NSE announcements, SEBI, RBI | Filings and regulatory actions | 0 |
| Company news search | Recent press about one stock, credited to the real publisher | per publisher |
| ET, Business Standard, Mint, Moneycontrol feeds | Latest market-wide headlines | 1 |
| ET Prime (extension) | Full text of articles you open | 1 |

How filings are handled:
- **Routine paperwork is skipped:** trading-window closures, newspaper copies,
  share-certificate notices and similar. The patterns are in `routine_filings`
  in `config/sources.yaml`.
- **Coming up:** board-meeting notices, record dates and earnings-call notices
  become a "Coming up" list in the dossier, each cited to its filing.
- **PDF figures:** reading the PDFs needs `pypdf`, which is in `requirements.txt`.

How stocks are matched (`config/watchlist.yaml`):
- `aliases` identify the company and are used for the news search.
- `link_only` lists short press names such as "Reliance", which are too broad to search with.
- `related` lists subsidiaries and assets ("Jio", "Jamnagar refinery"). A headline
  naming only these is kept, but ranked below news about the company itself.
- `exclude` lists look-alikes ("Reliance Power", "HDFC Life") that must not match.

The dossier covers 30 days by default. Use the selector in the UI, or `?days=90`
on the API, for a longer view.

## Enrichment

The rule-based enricher works offline. If `ANTHROPIC_API_KEY` is set, each linked article
is also labelled by the model in `sources.yaml → llm.model`, which gives better event
types, summaries and claims. If that call fails, the rules result is used instead.

## Check after the first run

- **Sources tab:** every feed URL in `sources.yaml` should show a recent check
  with no problem. Feed URLs move. Fix any that fail.
- **BSE** uses its unofficial JSON API with browser-like headers. It can change
  without notice. NSE's website API blocks scripts, so NSE comes in through its
  archive RSS instead.
- **A stock shows nothing:** run `python run.py check TICKER` first. It shows each
  source's result, so you can see whether a source failed or nothing matched.
- **Adding stocks:** give the BSE scrip code (on the company's bseindia.com page)
  so its filings are checked. Without it, the stock only gets press coverage.
  When you add a stock, recent articles that matched nothing are checked again for it.
- **Aliases:** if a stock shows no news you expected, add the names the press uses
  in `config/watchlist.yaml`. If it picks up other companies, add those names to `exclude`.

## Not built yet

- The novelty check against price moves (hook in `scoring.py`, `novelty = 1.0`).
  It needs Kite candles.
- A price/volume anomaly trigger from Kite.
- Exchange holidays. They are treated as trading days, which is harmless.
