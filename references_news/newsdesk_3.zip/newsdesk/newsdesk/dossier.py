"""Builds the per-stock dossier the news brain reads: ranked events, numbered
citations, conflicts and open questions."""
import json
from datetime import timedelta

from .clock import iso, now_utc, parse_iso
from .db import WRITE_LOCK
from .scoring import amounts_close, similarity, tokens
from .upcoming import upcoming_from_filing

FACT_LABEL = {"fact": "fact", "speculation": "speculation", "opinion": "opinion"}


def build(conn, ticker, window_days=30, limit=15):
    ticker = ticker.upper()
    now = now_utc()
    stock = conn.execute("SELECT * FROM watchlist WHERE ticker=?", (ticker,)).fetchone()
    if not stock:
        return None
    since = iso(now - timedelta(days=window_days))
    evs = conn.execute("""SELECT * FROM events WHERE ticker=? AND first_seen >= ?
        AND event_type != 'scheduled' ORDER BY score DESC LIMIT ?""", (ticker, since, limit)).fetchall()

    cit_ids, citations = {}, {}

    def cite(article_id, quote=None):
        if article_id not in cit_ids:
            a = conn.execute("""SELECT a.*, s.name sname, s.tier FROM articles a
                JOIN sources s ON s.id = a.source_id WHERE a.id=?""", (article_id,)).fetchone()
            n = len(cit_ids) + 1
            cit_ids[article_id] = n
            citations[str(n)] = {
                "n": n, "article_id": a["id"], "source": a["sname"], "tier": a["tier"],
                "title": a["title"], "url": a["url"], "published_at": a["published_at"],
                "fetched_at": a["fetched_at"], "snapshot_hash": a["content_hash"],
                "full_text_captured": not a["is_stub"],
                "quote": (quote or a["body"] or a["title"])[:280]}
        return cit_ids[article_id]

    events, conflicts, unknowns = [], [], []
    for ev in evs:
        arts = conn.execute("""SELECT a.id, a.direction, a.is_stub, s.tier, s.name FROM event_articles ea
            JOIN articles a ON a.id = ea.article_id JOIN sources s ON s.id = a.source_id
            WHERE ea.event_id=? ORDER BY s.tier, a.published_at""", (ev["id"],)).fetchall()
        claims = []
        for c in conn.execute("""SELECT c.* FROM claims c JOIN articles a ON a.id=c.article_id
                JOIN sources s ON s.id=a.source_id WHERE c.event_id=? ORDER BY s.tier, a.published_at""",
                (ev["id"],)).fetchall():
            ids = [c["article_id"]]
            if c["basis_article_id"] and c["basis_article_id"] != c["article_id"]:
                ids.append(c["basis_article_id"])
            toks = tokens(c["text"])
            dup = next((x for x in claims if similarity(toks, x["_t"]) >= 0.6
                        or (c["amount_cr"] and amounts_close(c["amount_cr"], x["amount_cr"])
                            and c["status"] in ("confirmed", "filed"))), None)
            if dup:      # same claim from another source: one line, more citations
                for i in ids:
                    n = cite(i, c["text"])
                    if n not in dup["citations"]:
                        dup["citations"].append(n)
                continue
            claims.append({"text": c["text"], "amount_cr": c["amount_cr"], "status": c["status"],
                           "citations": [cite(i, c["text"]) for i in ids], "_t": toks})
        for x in claims:
            x.pop("_t")
            x["citations"].sort()
        refs = sorted({cite(a["id"]) for a in arts})
        tiers = [{"citation": cite(a["id"]), "tier": a["tier"], "source": a["name"],
                  "stub": bool(a["is_stub"])} for a in arts]
        dirs = {a["direction"] for a in arts if a["direction"] in ("positive", "negative")}
        events.append({
            "id": f"evt_{ev['id']}", "type": ev["event_type"], "title": ev["title"],
            "summary": ev["summary"], "direction": ev["direction"], "fact_type": ev["fact_type"],
            "validation": ev["validation"], "amount_cr": ev["amount_cr"],
            "materiality": ev["materiality"], "confidence": ev["confidence"],
            "recency": ev["recency"], "score": ev["score"], "first_seen": ev["first_seen"],
            "sources": tiers, "corroboration": len({a["name"] for a in arts}),
            "claims": claims, "citations": refs, "price_move_since": None})
        if ev["validation"] in ("contradicted", "denied"):
            conflicts.append({"event": f"evt_{ev['id']}", "kind": ev["validation"],
                              "text": f"{ev['title']}: press report {ev['validation']} by a filing.",
                              "citations": refs})
        if len(dirs) > 1:
            conflicts.append({"event": f"evt_{ev['id']}", "kind": "direction",
                              "text": f"{ev['title']}: sources disagree on whether this is good or bad news.",
                              "citations": refs})
        if ev["validation"] == "unconfirmed" and (ev["materiality"] or 0) >= 0.5:
            unknowns.append({"text": f"No filing yet confirms: {ev['title']}", "citations": refs})
        if any(a["is_stub"] for a in arts):
            unknowns.append({"text": f"Only the headline is saved, not the full article: {ev['title']}",
                             "citations": refs})

    if not any(any(s["tier"] == 0 for s in e["sources"]) for e in events):
        unknowns.append({"text": f"No exchange filings for {ticker} in the last {window_days} days.",
                         "citations": []})

    # Scheduled events from the company's own notices (results dates, record dates, calls)
    upcoming = {}
    for a in conn.execute("""SELECT a.id, a.title, a.body, a.published_at FROM articles a
            JOIN article_tickers t ON t.article_id = a.id JOIN sources s ON s.id = a.source_id
            WHERE t.ticker=? AND s.tier=0 AND a.published_at >= ? ORDER BY a.published_at DESC""",
            (ticker, iso(now - timedelta(days=120)))).fetchall():
        for u in upcoming_from_filing(a["title"], a["body"], parse_iso(a["published_at"])):
            key = (u["date"], u["what"])
            if key not in upcoming:     # newest notice wins if a date was revised
                upcoming[key] = {**u, "citations": [cite(a["id"])]}

    st = conn.execute("SELECT last_ingest FROM ticker_state WHERE ticker=?", (ticker,)).fetchone()
    return {"ticker": ticker, "name": stock["name"], "as_of": iso(now), "window_days": window_days,
            "last_ingest": st["last_ingest"] if st else None,
            "events": events, "upcoming": sorted(upcoming.values(), key=lambda u: u["date"]),
            "conflicts": conflicts, "unknowns": unknowns, "citations": citations}


def to_markdown(d):
    """Compact text form for pasting into a brain's prompt. Every line carries [n] refs."""
    def refs(ns):
        return "".join(f"[{n}]" for n in ns)
    out = [f"# News dossier: {d['name']} ({d['ticker']})",
           f"As of {d['as_of']} UTC, window {d['window_days']} days. "
           "Rules: cite [n] for every claim you use; treat 'unconfirmed', 'speculation' and "
           "'opinion' as weaker evidence; do not use facts not listed here.", "", "## Events (ranked)"]
    for i, e in enumerate(d["events"], 1):
        out.append(f"{i}. {e['summary']} {refs(e['citations'])}")
        out.append(f"   type={e['type']} direction={e['direction']} status={e['validation']} "
                   f"kind={e['fact_type']} score={e['score']} confidence={e['confidence']} "
                   f"sources={e['corroboration']} first_seen={e['first_seen']}")
        for c in e["claims"]:
            out.append(f"   - {c['text']} ({c['status']}) {refs(c['citations'])}")
    if d.get("upcoming"):
        out += ["", "## Coming up (from company filings)"] + [
            f"- {u['date']}: {u['what']} {refs(u['citations'])}" for u in d["upcoming"]]
    if d["conflicts"]:
        out += ["", "## Conflicts"] + [f"- {c['text']} {refs(c['citations'])}" for c in d["conflicts"]]
    if d["unknowns"]:
        out += ["", "## Not yet known"] + [f"- {u['text']} {refs(u['citations'])}" for u in d["unknowns"]]
    out += ["", "## Citations"]
    for n, c in d["citations"].items():
        out.append(f"[{n}] {c['source']} (tier {c['tier']}), {c['published_at']}: {c['title']} <{c['url']}>")
    return "\n".join(out)


def cache(conn, ticker):
    d = build(conn, ticker)
    if d:
        with WRITE_LOCK, conn:
            conn.execute("INSERT INTO dossier_cache VALUES(?,?,?) ON CONFLICT(ticker) DO UPDATE "
                         "SET built_at=excluded.built_at, json=excluded.json",
                         (d["ticker"], d["as_of"], json.dumps(d)))
    return d
