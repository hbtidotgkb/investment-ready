"""newsdesk: curated, cited stock news dossiers for the news brain."""
