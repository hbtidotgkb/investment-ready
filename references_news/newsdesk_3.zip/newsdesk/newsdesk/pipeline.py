"""Raw items in, scored events out. Shared by the worker and the on-demand path."""
import hashlib
import json
import logging
import re
from datetime import timedelta

from .clock import iso, now_utc, parse_iso
from .config import load_sources, load_watchlist_file
from .db import WRITE_LOCK
from .enrich import enrich
from .linker import Linker
from .scoring import similarity, amounts_close, score_event, tokens, validate_event

ALERT_SCORE = 0.35
log = logging.getLogger("newsdesk.pipeline")


def bootstrap(conn):
    """Load sources and watchlist from config into the database (idempotent)."""
    cfg = load_sources()
    with WRITE_LOCK, conn:
        for s in cfg.get("sources", []):
            conn.execute("""INSERT INTO sources(id, name, tier, trust, base_trust, kind)
                VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                tier=excluded.tier, base_trust=excluded.base_trust, kind=excluded.kind""",
                (s["id"], s["name"], s["tier"], s["trust"], s["trust"], s["kind"]))
        conn.execute("""INSERT OR IGNORE INTO sources(id, name, tier, trust, base_trust, kind)
            VALUES('manual','Captured by you',1,0.8,0.8,'manual')""")
        for st in load_watchlist_file():
            upsert_stock(conn, st)
    return cfg


def upsert_stock(conn, st):
    conn.execute("""INSERT INTO watchlist(ticker, name, bse_scrip, aliases, exclude, market_cap_cr,
        link_only, related) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(ticker) DO UPDATE SET
        name=excluded.name, bse_scrip=excluded.bse_scrip, aliases=excluded.aliases,
        exclude=excluded.exclude, market_cap_cr=excluded.market_cap_cr,
        link_only=excluded.link_only, related=excluded.related""",
        (st["ticker"].upper(), st["name"], str(st.get("bse_scrip") or "") or None,
         json.dumps(st.get("aliases") or [st["name"]]), json.dumps(st.get("exclude") or []),
         st.get("market_cap_cr"), json.dumps(st.get("link_only") or []),
         json.dumps(st.get("related") or [])))


def _is_paid(item, markers):
    text = f"{item.title} {item.body}".lower()
    return next((m for m in markers if m.lower() in text), None)


def _find_event(conn, ticker, etype, toks, amount, published, tier):
    clar = etype == "clarification" and tier == 0
    window = timedelta(days=7 if clar else 3)
    rows = conn.execute("SELECT * FROM events WHERE ticker=? AND last_updated >= ?",
                        (ticker, iso(published - window))).fetchall()
    best, best_sim = None, 0.0
    for ev in rows:
        if abs((parse_iso(ev["first_seen"]) - published).total_seconds()) > window.total_seconds():
            continue
        sim = similarity(toks, set(json.loads(ev["sig"] or "[]")))
        if amount and amounts_close(amount, ev["amount_cr"]):
            sim += 0.4
        if clar:
            need = 0.2
        elif ev["event_type"] == etype:
            need = 0.25
        else:
            need = 0.5
        if sim >= need and sim > best_sim:
            best, best_sim = ev, sim
    return best


def _is_routine(item, patterns):
    text = f"{item.title} {item.category or ''}".lower()
    return next((p for p in patterns if re.search(p, text)), None)


def process(conn, items, cfg=None, linker=None, pdf_fetcher=None):
    """Returns a list of dicts describing events that changed.
    pdf_fetcher(url) -> text: reads a linked filing's PDF (default: sources.pdf_text)."""
    cfg = cfg or load_sources()
    markers = cfg.get("paid_markers", [])
    routine = cfg.get("routine_filings", [])
    if pdf_fetcher is None:
        from .sources import pdf_text as pdf_fetcher
    linker = linker or Linker.from_db(conn)
    tiers = {r["id"]: r["tier"] for r in conn.execute("SELECT id, tier FROM sources")}
    names = {r["ticker"]: r for r in conn.execute("SELECT * FROM watchlist")}
    changed = {}
    now = now_utc()

    for item in items:
        with WRITE_LOCK, conn:
            tier = tiers.get(item.source_id, 1)
            existing = conn.execute("SELECT * FROM articles WHERE url=?", (item.url,)).fetchone()
            if existing:
                if not (existing["is_stub"] and not item.is_stub and item.body):
                    continue
                # full text arrived for a stub: replace it and re-run the article
                if not item.tickers and existing["hint_tickers"]:
                    item.tickers = tuple(json.loads(existing["hint_tickers"]))
                old_events = [r["event_id"] for r in conn.execute(
                    "SELECT event_id FROM event_articles WHERE article_id=?", (existing["id"],))]
                conn.execute("DELETE FROM claims WHERE article_id=?", (existing["id"],))
                conn.execute("DELETE FROM event_articles WHERE article_id=?", (existing["id"],))
                conn.execute("DELETE FROM article_tickers WHERE article_id=?", (existing["id"],))
                conn.execute("DELETE FROM articles WHERE id=?", (existing["id"],))
                for eid in old_events:
                    if not conn.execute("SELECT 1 FROM event_articles WHERE event_id=?", (eid,)).fetchone():
                        conn.execute("DELETE FROM events WHERE id=?", (eid,))

            paid = _is_paid(item, markers)
            dull = _is_routine(item, routine) if tier == 0 else None
            links = {} if (paid or dull) else linker.link(item.title, item.body, item.scrip,
                                                          tickers=item.tickers)
            if links and tier == 0 and item.url.lower().endswith(".pdf") and len(item.body) < 500:
                try:   # the subject line rarely carries the numbers; the attachment does
                    text = pdf_fetcher(item.url)
                    if text:
                        item.body = text
                except Exception as e:
                    log.info("could not read %s: %s", item.url, e)
            h = hashlib.sha256(f"{item.title}\n{item.body}".encode()).hexdigest()
            primary = max(links, key=links.get) if links else None
            info = enrich(item.title, item.body, primary, item.category, tier, cfg.get("llm")) if links else {}
            cur = conn.execute("""INSERT INTO articles(source_id, url, title, body, published_at,
                fetched_at, content_hash, is_stub, category, scrip, direction, dropped_reason,
                hint_tickers) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (item.source_id, item.url, item.title, item.body, iso(item.published_at), iso(now),
                 h, int(item.is_stub), item.category, item.scrip, info.get("direction"),
                 f"paid content ({paid})" if paid else f"routine filing ({dull})" if dull
                 else (None if links else "no watchlist match"),
                 json.dumps(list(item.tickers)) if item.tickers else None))
            aid = cur.lastrowid
            conn.execute("UPDATE sources SET items_total = items_total + 1 WHERE id=?", (item.source_id,))

            for ticker, sal in links.items():
                conn.execute("INSERT INTO article_tickers VALUES(?,?,?)", (aid, ticker, sal))
                stock = names.get(ticker)
                drop = (json.loads(stock["aliases"]) + json.loads(stock["link_only"] or "[]")) if stock else []
                toks = tokens(f"{item.title} {item.body[:500]}", drop=drop)
                ev = _find_event(conn, ticker, info["event_type"], toks, info.get("amount_cr"),
                                 item.published_at, tier)
                if ev is None:
                    cur = conn.execute("""INSERT INTO events(ticker, event_type, title, summary,
                        direction, fact_type, amount_cr, sig, validation, first_seen, last_updated)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                        (ticker, info["event_type"], item.title, info.get("summary") or item.title,
                         info["direction"], info["fact_type"], info.get("amount_cr"),
                         json.dumps(sorted(toks)[:200]), "unconfirmed",
                         iso(item.published_at), iso(now)))
                    eid, was_new, old_val, old_score = cur.lastrowid, True, None, 0.0
                else:
                    eid, was_new, old_val, old_score = ev["id"], False, ev["validation"], ev["score"] or 0
                    sig = sorted(set(json.loads(ev["sig"] or "[]")) | toks)[:300]
                    upd = {"sig": json.dumps(sig), "last_updated": iso(now),
                           "first_seen": min(ev["first_seen"], iso(item.published_at))}
                    if tier == 0 and info["event_type"] != "clarification":
                        # the filing's figures are authoritative; the press headline reads better
                        upd.update(fact_type="fact", amount_cr=info.get("amount_cr") or ev["amount_cr"])
                    else:
                        if not ev["amount_cr"] and info.get("amount_cr"):
                            upd["amount_cr"] = info["amount_cr"]
                        has_press = conn.execute("""SELECT 1 FROM event_articles ea JOIN articles a
                            ON a.id=ea.article_id JOIN sources s ON s.id=a.source_id
                            WHERE ea.event_id=? AND s.tier>0""", (eid,)).fetchone()
                        if tier > 0 and not has_press:
                            upd["summary"] = item.title
                    conn.execute(f"UPDATE events SET {', '.join(k + '=?' for k in upd)} WHERE id=?",
                                 (*upd.values(), eid))
                conn.execute("INSERT OR IGNORE INTO event_articles VALUES(?,?)", (eid, aid))
                for c in info.get("claims", []):
                    conn.execute("INSERT INTO claims(event_id, article_id, text, amount_cr, status) "
                                 "VALUES(?,?,?,?,?)", (eid, aid, c["text"], c.get("amount_cr"), None))
                new_val = validate_event(conn, eid)
                new_score = score_event(conn, eid, now)
                conn.execute("INSERT INTO ticker_state VALUES(?,?) ON CONFLICT(ticker) DO UPDATE "
                             "SET last_ingest=excluded.last_ingest", (ticker, iso(now)))
                _alerts(conn, ticker, eid, item, tier, was_new, old_val, new_val, old_score, new_score, now)
                changed[eid] = {"event_id": eid, "ticker": ticker, "validation": new_val,
                                "score": new_score}
    return list(changed.values())


def _alerts(conn, ticker, eid, item, tier, was_new, old_val, new_val, old_score, new_score, now):
    msgs = []
    if tier == 0 and was_new:
        msgs.append(("filing", f"New filing: {item.title}"))
    if new_val != old_val and new_val in ("denied", "contradicted") and not was_new:
        msgs.append(("validation", f"Press report now {new_val} by a filing: {item.title}"))
    if old_score < ALERT_SCORE <= new_score:
        msgs.append(("impact", f"High-impact event: {item.title}"))
    for kind, msg in msgs:
        conn.execute("INSERT INTO alerts(ticker, event_id, kind, message, created_at) VALUES(?,?,?,?,?)",
                     (ticker, eid, kind, msg[:300], iso(now)))


def rescore_all(conn, days=60):
    """Nightly: decay, re-validate unconfirmed, retrain trust."""
    from .scoring import recalibrate_trust
    cutoff = iso(now_utc() - timedelta(days=days))
    with WRITE_LOCK, conn:
        recalibrate_trust(conn)
        for ev in conn.execute("SELECT id FROM events WHERE last_updated >= ?", (cutoff,)).fetchall():
            validate_event(conn, ev["id"])
            score_event(conn, ev["id"])


def relink(conn, cfg=None, days=30):
    """After a stock is added, re-run recent articles that matched nothing,
    so news fetched before it was on the watchlist still reaches it."""
    from .sources import RawItem
    cutoff = iso(now_utc() - timedelta(days=days))
    rows = conn.execute("""SELECT * FROM articles WHERE dropped_reason='no watchlist match'
        AND published_at >= ?""", (cutoff,)).fetchall()
    items = [RawItem(r["source_id"], r["url"], r["title"], r["body"] or "",
                     parse_iso(r["published_at"]), r["category"], r["scrip"], bool(r["is_stub"]),
                     tuple(json.loads(r["hint_tickers"] or "[]")))
             for r in rows]
    with WRITE_LOCK, conn:
        conn.executemany("DELETE FROM articles WHERE id=?", [(r["id"],) for r in rows])
    return process(conn, items, cfg)
