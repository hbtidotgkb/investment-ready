"""Market clock for NSE/BSE (IST). Weekends count as overnight.
Exchange holidays are not modelled; polling on a holiday is harmless, just quiet."""
from datetime import datetime, time, timezone
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")


def now_utc():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def parse_iso(s):
    return datetime.fromisoformat(s) if s else None


def phase(dt=None):
    t = (dt or now_utc()).astimezone(IST)
    if t.weekday() >= 5:
        return "overnight"
    hm = t.time()
    if time(7, 0) <= hm < time(9, 15):
        return "premarket"
    if time(9, 15) <= hm < time(15, 30):
        return "market"
    if time(15, 30) <= hm < time(22, 0):
        return "postmarket"
    return "overnight"
