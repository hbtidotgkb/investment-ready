"""Local HTTP server: UI, dossier API, and the capture endpoint for the ET Prime extension.
Binds to 127.0.0.1 by default. Standard library only."""
import json
import logging
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import dossier
from .clock import now_utc
from .config import load_sources
from .db import WRITE_LOCK, connect
from .pipeline import process, relink, upsert_stock
from .sources import RawItem, _parse_date, clean_text
from .worker import refresh_ticker

log = logging.getLogger("newsdesk.server")
UI = Path(__file__).parent / "ui" / "index.html"
INGEST_TOKEN = os.environ.get("NEWSDESK_INGEST_TOKEN")


class Handler(BaseHTTPRequestHandler):
    server_version = "newsdesk"

    def log_message(self, fmt, *args):
        log.debug(fmt, *args)

    # -- helpers ---------------------------------------------------------
    @property
    def conn(self):
        # one SQLite connection per request: safe with the threaded server
        if getattr(self, "_conn", None) is None:
            self._conn = connect()
        return self._conn

    def finish(self):
        super().finish()
        if getattr(self, "_conn", None) is not None:
            self._conn.close()

    def send(self, status, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else (
            body.encode() if isinstance(body, str) else json.dumps(body, default=str).encode())
        self.send_response(status)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.cors()
        self.end_headers()
        self.wfile.write(data)

    def cors(self):
        origin = self.headers.get("Origin") or ""
        if origin.startswith("chrome-extension://") or origin.startswith("http://127.0.0.1"):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Ingest-Token")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.end_headers()

    # -- routes ----------------------------------------------------------
    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[-1] for k, v in parse_qs(u.query).items()}
        p = u.path.rstrip("/") or "/"
        try:
            if p == "/":
                return self.send(200, UI.read_bytes(), "text/html")
            if p == "/api/watchlist":
                rows = self.conn.execute("""SELECT w.ticker, w.name, t.last_ingest,
                    (SELECT COUNT(*) FROM alerts a WHERE a.ticker=w.ticker AND a.seen=0) unseen
                    FROM watchlist w LEFT JOIN ticker_state t ON t.ticker=w.ticker ORDER BY w.ticker""")
                return self.send(200, [dict(r) for r in rows])
            m = re.fullmatch(r"/api/dossier/([A-Za-z0-9&_-]+)", p)
            if m:
                return self.dossier(m.group(1), q)
            m = re.fullmatch(r"/api/article/(\d+)", p)
            if m:
                a = self.conn.execute("""SELECT a.*, s.name source, s.tier FROM articles a
                    JOIN sources s ON s.id=a.source_id WHERE a.id=?""", (int(m.group(1)),)).fetchone()
                return self.send(200, dict(a)) if a else self.send(404, {"error": "No such article."})
            if p == "/api/sources":
                rows = self.conn.execute("SELECT * FROM sources ORDER BY tier, name")
                return self.send(200, [dict(r) for r in rows])
            if p == "/api/alerts":
                rows = self.conn.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100")
                return self.send(200, [dict(r) for r in rows])
            return self.send(404, {"error": "Unknown path."})
        except Exception as e:
            log.exception("GET %s", p)
            return self.send(500, {"error": f"{type(e).__name__}: {e}"})

    def dossier(self, ticker, q):
        ticker = ticker.upper()
        if not self.conn.execute("SELECT 1 FROM watchlist WHERE ticker=?", (ticker,)).fetchone():
            return self.send(404, {"error": f"{ticker} isn't on the watchlist. Add it first."})
        mode = q.get("refresh", "auto")
        refresh = {"refreshed": False, "reason": "skipped"}
        if mode in ("auto", "force"):
            refresh = refresh_ticker(self.conn, self.server.cfg, ticker, force=mode == "force")
        days = max(7, min(365, int(q.get("days") or 30)))
        d = dossier.cache(self.conn, ticker) if days == 30 else dossier.build(self.conn, ticker, days)
        d["refresh"] = refresh
        if q.get("format") == "md":
            return self.send(200, dossier.to_markdown(d), "text/markdown")
        return self.send(200, d)

    def do_POST(self):
        p = urlparse(self.path).path.rstrip("/")
        try:
            if p == "/api/ingest":
                return self.ingest()
            if p == "/api/ingest/batch":
                return self.ingest_batch()
            if p == "/api/watchlist":
                b = self.body_json()
                if not b.get("ticker") or not b.get("name"):
                    return self.send(400, {"error": "Ticker and company name are both needed."})
                b["aliases"] = [a.strip() for a in (b.get("aliases") or [b["name"]]) if a.strip()]
                with WRITE_LOCK, self.conn:
                    upsert_stock(self.conn, b)
                changed = relink(self.conn, self.server.cfg)
                return self.send(200, {"ok": True, "ticker": b["ticker"].upper(),
                                       "linked_from_earlier": len(changed)})
            if p == "/api/alerts/seen":
                b = self.body_json()
                with WRITE_LOCK, self.conn:
                    if b.get("ticker"):
                        self.conn.execute("UPDATE alerts SET seen=1 WHERE ticker=?", (b["ticker"].upper(),))
                    else:
                        self.conn.execute("UPDATE alerts SET seen=1")
                return self.send(200, {"ok": True})
            return self.send(404, {"error": "Unknown path."})
        except Exception as e:
            log.exception("POST %s", p)
            return self.send(500, {"error": f"{type(e).__name__}: {e}"})

    def authorised(self):
        return not INGEST_TOKEN or self.headers.get("X-Ingest-Token") == INGEST_TOKEN

    def to_item(self, b, known):
        """One posted article or headline -> RawItem. Returns None if unusable."""
        url, title = (b.get("url") or "").strip(), clean_text(b.get("title") or "")
        if not url or not title:
            return None
        body = clean_text(b.get("body") or "")
        if b.get("provider"):
            src = map_provider(b["provider"], self.server.cfg)
        else:
            src = b.get("source") or ("et_prime" if "economictimes" in url else "manual")
        if src not in known:
            src = "manual"
        return RawItem(src, url, title, body,
                       _parse_date(b["published_at"]) if b.get("published_at") else now_utc(),
                       category=b.get("provider"), is_stub=len(body) < 300,
                       tickers=tuple(parse_symbols(b.get("symbols"))))

    def ingest(self):
        """An article you opened, posted by the extension.
        Body: {url, title, body, published_at?, source? | provider?, symbols?}"""
        if not self.authorised():
            return self.send(401, {"error": "Missing or wrong X-Ingest-Token."})
        b = self.body_json()
        if not b.get("url") or not b.get("body"):
            return self.send(400, {"error": "url and body are required."})
        known = {r["id"] for r in self.conn.execute("SELECT id FROM sources")}
        item = self.to_item(b, known)
        if item is None:
            return self.send(400, {"error": "A title is required."})
        item.is_stub = False
        return self.send(200, self.run_items([item]))

    def ingest_batch(self):
        """A batch of headlines from another tool of yours.
        Body: {items: [{url, title, provider, symbols?, published_at?, body?}]}"""
        if not self.authorised():
            return self.send(401, {"error": "Missing or wrong X-Ingest-Token."})
        raw = (self.body_json().get("items") or [])[:200]
        known = {r["id"] for r in self.conn.execute("SELECT id FROM sources")}
        items = [i for i in (self.to_item(b, known) for b in raw) if i]
        return self.send(200, {"received": len(raw), "usable": len(items), **self.run_items(items)})

    def run_items(self, items):
        changed = process(self.conn, items, self.server.cfg)
        for t in {c["ticker"] for c in changed}:
            dossier.cache(self.conn, t)
        return {"ok": True, "events_changed": changed}


def map_provider(name, cfg):
    """Publisher name or slug -> one of our source ids."""
    tv = cfg.get("provider_names") or {}
    key = re.sub(r"[^a-z0-9_]", "", str(name).lower().replace(" ", "_").replace("-", "_"))
    for needle, sid in (tv.get("providers") or {}).items():
        if needle in key:
            return sid
    return tv.get("default_source", "web_other")


def parse_symbols(symbols):
    """'NSE:RELIANCE', 'BSE-AXISBANK' -> ticker. Other exchanges are ignored."""
    out = []
    for s in symbols or []:
        m = re.fullmatch(r"(NSE|BSE)[:\-]([A-Z0-9&_\-]+)", str(s).strip().upper())
        if m and m.group(2) not in out:
            out.append(m.group(2))
    return out


def serve(host="127.0.0.1", port=8765):
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.cfg = load_sources()
    log.info("serving on http://%s:%d", host, port)
    httpd.serve_forever()
