"""Turns an article into structured fields: event type, direction, fact vs opinion,
amount, and atomic claims. Rule-based by default; uses Claude when a key is set."""
import json
import os
import re

import requests

# type: (base materiality, half-life in hours, patterns)
EVENT_TYPES = {
    # notices of something still to happen; shown under "Coming up", not as news
    "scheduled": (0.15, 336, r"board meeting intimation|intimation (of|for|regarding) (the )?board meeting|"
                             r"prior intimation|meeting of the board.{0,80}\bwill be held\b|"
                             r"(intimation|schedule) of (an? )?(earnings|conference|analyst) call"),
    "regulatory_action": (0.75, 1440, r"\bsebi\b.*\b(order|penalt|show.cause|ban|probe)|\brbi\b.*\b(penalt|restrict|curb)|show.cause notice|\bpenalty\b|\bbarred\b"),
    "governance_flag": (0.80, 2160, r"related.party|auditor (resign|quit|qualif)|corporate governance|forensic audit|whistle.?blower|siphon|fund diversion"),
    "accounting_concern": (0.80, 2160, r"restat|accounting (irregular|lapse)|qualified opinion|contingent liabilit|receivables"),
    "clarification": (0.40, 168, r"clarification|clarifies|denies|news item|media report|market rumou?r|price movement"),
    "results": (0.70, 336, r"\bq[1-4]\b|quarterly results|financial results|net profit|\bpat\b|\bebitda\b|results for the (quarter|period)"),
    "guidance": (0.65, 336, r"guidance|outlook|forecast|expects? (revenue|growth|margin)"),
    "m_and_a": (0.75, 720, r"acquisi|acquire|merger|amalgamat|demerg|takeover|stake (sale|purchase)|open offer"),
    "order_win": (0.50, 168, r"\border(s)?\b.*\b(win|won|bag|secur|receiv)|\b(won|wins|bags?|bagged|secured?|received?|receipt of)\b (an? |the )?(new |large |major |significant )?orders?\b|order inflow|letter of award|\bLoA\b|contract (win|award)"),
    "rating_action": (0.55, 720, r"\b(crisil|icra|care ratings|india ratings|moody|fitch|s&p)\b|credit rating|rating (upgrade|downgrade|reaffirm)"),
    "insider_pledge": (0.55, 720, r"pledge|insider trad|\bsast\b|promoter (sell|buy|stake|holding)|block deal|bulk deal"),
    "management_change": (0.50, 336, r"resign|appoint|\bceo\b|\bcfo\b|managing director|steps down|key managerial"),
    "litigation": (0.55, 720, r"\bnclt\b|court|tribunal|arbitration|lawsuit|insolvency|\bed\b raid|income tax (raid|search)"),
    "fundraise": (0.50, 336, r"\bqip\b|rights issue|preferential (issue|allot)|fund.?rais|\bncd|bond issue|\bipo\b"),
    "capex": (0.45, 336, r"capex|capacity expansion|new plant|commission(ed|ing)|greenfield"),
    "dividend_buyback": (0.35, 168, r"dividend|buy.?back|bonus issue|stock split|record date"),
    "analyst_view": (0.20, 72, r"target price|\b(buy|sell|hold|accumulate|reduce) (rating|call)\b|brokerage|stocks? to buy|should you"),
    "sector_macro": (0.30, 120, r"\bsector\b|industry|\bpolicy\b|tariff|\bgdp\b|inflation|repo rate"),
    "other": (0.15, 72, r""),
}

BSE_CATEGORY_MAP = {
    "result": "results", "insider trading / sast": "insider_pledge", "corp. action": "dividend_buyback",
    "agm/egm": "other", "board meeting": "other", "new listing": "other",
}

POSITIVE = r"\b(surge|jump|soar|rise|rises|gain|beat|record|upgrade|wins?|bags?|secures?|strong|growth|profit up|expands?|approval|order)\b"
NEGATIVE = r"\b(fall|falls|slump|plunge|drop|decline|miss|downgrade|loss|penalt|probe|resign|default|pledge|cut|weak|concern|fraud|raid|ban|denies)\b"
SPECULATION = r"sources (said|say)|people (familiar|aware)|according to people|reportedly|likely to|in talks|is said to|considering|mulls|could\b"
OPINION = r"target price|should you|stocks? to buy|our view|analysts? (say|believe|see)|brokerage|recommend"

AMOUNT = re.compile(
    r"(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d+)?)\s*(lakh crore|lakh cr|crore|cr\b|billion|bn\b|million|mn\b|lakh)?"
    r"|([\d,]+(?:\.\d+)?)\s*(lakh crore|crore|cr\b)",
    re.IGNORECASE)
UNIT_TO_CR = {"lakh crore": 1e5, "lakh cr": 1e5, "crore": 1, "cr": 1, "billion": 100, "bn": 100,
              "million": 0.1, "mn": 0.1, "lakh": 0.01}


def amounts_cr(text):
    out = []
    for m in AMOUNT.finditer(text or ""):
        num, unit = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        if not unit:
            continue
        try:
            val = float(num.replace(",", ""))
        except ValueError:
            continue
        out.append(val * UNIT_TO_CR[unit.lower().strip()])
    return out


def classify(title, body, category=None, tier=1):
    text = f"{title}. {body[:1500]}".lower()
    if category:
        cat = BSE_CATEGORY_MAP.get(category.strip().lower())
        if cat and cat != "other":
            return cat
    for etype, (_, _, pat) in EVENT_TYPES.items():
        if pat and re.search(pat, text, re.IGNORECASE):
            if etype == "clarification" and tier > 0:
                continue          # only a filing is a clarification; press "denies" is just news
            return etype
    return "other"


def direction(text):
    p = len(re.findall(POSITIVE, text, re.IGNORECASE))
    n = len(re.findall(NEGATIVE, text, re.IGNORECASE))
    if p > n:
        return "positive"
    if n > p:
        return "negative"
    return "neutral"


def fact_type(text, tier, etype):
    if tier == 0:
        return "fact"
    if etype == "analyst_view" or re.search(OPINION, text, re.IGNORECASE):
        return "opinion"
    if re.search(SPECULATION, text, re.IGNORECASE):
        return "speculation"
    return "fact"


def extract_claims(title, body, limit=3):
    """Sentences that state something checkable: ones with an amount first,
    else the lead sentence, else the headline."""
    sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", (body or "")[:1200]) if len(x.strip()) >= 20]
    with_amt = [x for x in sents if amounts_cr(x)]
    picked = with_amt[:limit] or sents[:1] or [title]
    if not with_amt and amounts_cr(title):
        picked = [title]
    return [{"text": x[:300], "amount_cr": max(amounts_cr(x)) if amounts_cr(x) else None} for x in picked]


def lead_sentence(title, body):
    sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", (body or "")[:600]) if len(x.strip()) >= 20]
    return sents[0][:220] if sents else title


def enrich_rules(title, body, category=None, tier=1):
    etype = classify(title, body, category, tier)
    text = f"{title}. {body[:1500]}"
    amts = amounts_cr(f"{title}. {body[:600]}")
    return {
        "event_type": etype,
        "direction": direction(text),
        "fact_type": fact_type(text, tier, etype),
        "amount_cr": max(amts) if amts else None,
        "summary": lead_sentence(title, body) if tier == 0 else title,
        "claims": extract_claims(title, body),
    }


LLM_PROMPT = """You label Indian stock-market news for a structured event store.
Article source tier: {tier} (0 = exchange filing or regulator, 1 = financial press).
Company in focus: {ticker}

Title: {title}
Text: {body}

Return only a JSON object, no prose, with keys:
event_type: one of {types}
direction: positive | negative | neutral (for {ticker}'s shareholders)
fact_type: fact | speculation | opinion
amount_cr: the main rupee amount in crore as a number, or null
summary: one plain sentence, under 30 words, stating what happened
claims: up to 3 objects {{"text": an atomic factual claim copied closely from the text, "amount_cr": number or null}}"""


def enrich_llm(title, body, ticker, category, tier, model):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    prompt = LLM_PROMPT.format(tier=tier, ticker=ticker, title=title, body=(body or "")[:4000],
                               types=", ".join(EVENT_TYPES))
    r = requests.post("https://api.anthropic.com/v1/messages", timeout=40, headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": model, "max_tokens": 600, "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    text = "".join(b.get("text", "") for b in r.json().get("content", []))
    data = json.loads(re.sub(r"```(json)?", "", text).strip())
    if data.get("event_type") not in EVENT_TYPES:
        data["event_type"] = "other"
    if tier == 0:
        data["fact_type"] = "fact"
    return data


def enrich(title, body, ticker=None, category=None, tier=1, llm_cfg=None):
    base = enrich_rules(title, body, category, tier)
    if llm_cfg and llm_cfg.get("enabled") and os.environ.get("ANTHROPIC_API_KEY"):
        try:
            data = enrich_llm(title, body, ticker, category, tier, llm_cfg.get("model"))
            if data:
                return {**base, **{k: v for k, v in data.items() if v not in (None, "", [])}}
        except Exception:
            pass        # rules result stands; the LLM is an upgrade, not a dependency
    return base
