"""Offline tests: no network. Run with  python -m unittest discover tests"""
import unittest
from datetime import datetime, timedelta, timezone

from newsdesk import dossier
from newsdesk.clock import IST, phase
from newsdesk.db import connect
from newsdesk.enrich import amounts_cr, enrich_rules
from newsdesk.linker import Linker
from newsdesk.pipeline import bootstrap, process
from newsdesk.sources import RawItem, parse_bse_rows, parse_feed

T0 = datetime.now(timezone.utc) - timedelta(hours=3)


def item(src, url, title, body="", mins=0, **kw):
    return RawItem(src, url, title, body, T0 + timedelta(minutes=mins), **kw)


class Base(unittest.TestCase):
    def setUp(self):
        self.conn = connect(":memory:")
        self.cfg = bootstrap(self.conn)
        self.cfg["llm"] = {"enabled": False}

    def run_items(self, items):
        return process(self.conn, items, self.cfg)

    def events(self, ticker):
        return self.conn.execute("SELECT * FROM events WHERE ticker=?", (ticker,)).fetchall()


class TestParsing(unittest.TestCase):
    def test_amounts(self):
        self.assertEqual(amounts_cr("order worth ₹2,100 crore"), [2100])
        self.assertEqual(amounts_cr("Rs 1.2 lakh crore capex"), [120000])
        self.assertEqual(amounts_cr("INR 5 billion"), [500])
        self.assertEqual(amounts_cr("up 12% on volume"), [])

    def test_rss_and_atom(self):
        rss = b"""<rss><channel><item><title>L&amp;T bags order</title><link>https://x/1</link>
        <description>&lt;p&gt;Big win&lt;/p&gt;</description><pubDate>Fri, 20 Nov 2026 10:00:00 +0530</pubDate>
        </item></channel></rss>"""
        items = parse_feed("et_markets", rss)
        self.assertEqual(items[0].title, "L&T bags order")
        self.assertEqual(items[0].body, "Big win")
        self.assertEqual(items[0].published_at.hour, 4)  # 10:00 IST = 04:30 UTC
        atom = b"""<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>A</title>
        <link href="https://x/2"/><updated>2026-11-20T10:00:00Z</updated></entry></feed>"""
        self.assertEqual(parse_feed("mint", atom)[0].url, "https://x/2")

    def test_bse_rows(self):
        rows = [{"NEWSID": "abc", "SCRIP_CD": 500510, "SLONGNAME": "Larsen & Toubro Ltd",
                 "NEWSSUB": "Order win", "HEADLINE": "Received order of Rs 2,100 crore",
                 "DT_TM": "2026-11-20T18:45:12.67", "ATTACHMENTNAME": "f.pdf",
                 "CATEGORYNAME": "Company Update"}]
        it = parse_bse_rows("bse", rows)[0]
        self.assertEqual(it.scrip, "500510")
        self.assertTrue(it.url.endswith("/f.pdf"))
        self.assertEqual(it.published_at.tzinfo, timezone.utc)

    def test_phase(self):
        d = datetime(2026, 11, 20, 10, 0, tzinfo=IST)   # Friday
        self.assertEqual(phase(d), "market")
        self.assertEqual(phase(d.replace(hour=8)), "premarket")
        self.assertEqual(phase(d.replace(hour=17)), "postmarket")
        self.assertEqual(phase(d.replace(hour=23)), "overnight")
        self.assertEqual(phase(datetime(2026, 11, 21, 10, 0, tzinfo=IST)), "overnight")  # Saturday

    def test_enrich_rules(self):
        e = enrich_rules("Reliance in talks to acquire stake in X, sources said", "", tier=1)
        self.assertEqual(e["event_type"], "m_and_a")
        self.assertEqual(e["fact_type"], "speculation")
        self.assertEqual(enrich_rules("Results for the quarter", "", "Result", 0)["event_type"], "results")


class TestLinker(Base):
    def test_exclusions_and_scrip(self):
        lk = Linker.from_db(self.conn)
        self.assertEqual(lk.link("HDFC Life shares rise 4%", "HDFC Life reported..."), {})
        self.assertIn("HDFCBANK", lk.link("HDFC Bank Q2 profit up", ""))
        self.assertEqual(lk.link("Anything", "", scrip="500510"), {"LT": 1.0})
        self.assertNotIn("LT", lk.link("L&T Finance raises funds", "L&T Finance said"))
        # passing mention deep in the body is below the salience bar
        self.assertNotIn("NTPC", lk.link("Power stocks today", "x " * 300 + "NTPC also traded"))


class TestPipeline(Base):
    def test_filing_confirms_press(self):
        self.run_items([
            item("bse", "https://bse/1", "Larsen & Toubro Ltd: Order win",
                 "L&T has received an order worth Rs 2,100 crore from NHAI.", scrip="500510"),
            item("et_markets", "https://et/1", "L&T bags ₹2,100 crore NHAI highway order",
                 "Larsen & Toubro said it won an order of ₹2,100 crore from NHAI.", mins=20),
            item("mint", "https://mint/1", "L&T wins ₹2,100 crore order from NHAI",
                 "Larsen & Toubro bagged a highway order.", mins=35),
        ])
        evs = self.events("LT")
        self.assertEqual(len(evs), 1, [dict(e) for e in evs])
        ev = evs[0]
        self.assertEqual(ev["event_type"], "order_win")
        self.assertEqual(ev["validation"], "confirmed")
        self.assertGreaterEqual(ev["confidence"], 0.9)
        statuses = {r["status"] for r in self.conn.execute("SELECT status FROM claims")}
        self.assertTrue(statuses <= {"filed", "confirmed"}, statuses)
        src = self.conn.execute("SELECT confirmed FROM sources WHERE id='et_markets'").fetchone()
        self.assertGreaterEqual(src["confirmed"], 1)

    def test_wrong_amount_is_contradicted(self):
        self.run_items([
            item("bse", "https://bse/2", "Larsen & Toubro Ltd: Order win",
                 "L&T has received an order worth Rs 2,100 crore from NHAI.", scrip="500510"),
            item("moneycontrol", "https://mc/2", "L&T bags ₹2,500 crore NHAI order",
                 "Larsen & Toubro won an NHAI order of ₹2,500 crore.", mins=10),
        ])
        evs = self.events("LT")
        self.assertEqual(len(evs), 1)
        self.assertEqual(evs[0]["validation"], "contradicted")

    def test_rumour_then_denial(self):
        self.run_items([item("mint", "https://mint/r", "Reliance Industries in talks to acquire Acme Foods, sources said",
                             "Reliance Industries is in talks to acquire Acme Foods for ₹5,000 crore, people familiar said.")])
        ev = self.events("RELIANCE")[0]
        self.assertEqual(ev["validation"], "unconfirmed")
        self.assertEqual(ev["fact_type"], "speculation")
        before = ev["score"]
        changed = self.run_items([item("bse", "https://bse/c", "Reliance Industries Ltd: Clarification on news item",
                                       "With reference to the news item on Acme Foods acquisition, the company "
                                       "denies the report; there is no such proposal.", mins=120, scrip="500325")])
        ev = self.events("RELIANCE")
        self.assertEqual(len(ev), 1, [dict(e) for e in ev])
        self.assertEqual(ev[0]["validation"], "denied")
        self.assertLess(ev[0]["score"], before)
        kinds = {r["kind"] for r in self.conn.execute("SELECT kind FROM alerts WHERE ticker='RELIANCE'")}
        self.assertIn("validation", kinds)
        self.assertTrue(changed)

    def test_unrelated_events_stay_separate(self):
        self.run_items([
            item("bse", "https://bse/3", "Larsen & Toubro Ltd: Order win",
                 "L&T has received an order worth Rs 2,100 crore from NHAI.", scrip="500510"),
            item("et_markets", "https://et/3", "L&T Q2 results: net profit rises 12% to ₹3,400 crore",
                 "Larsen & Toubro reported quarterly results with net profit up 12%.", mins=30),
            item("mint", "https://mint/3", "L&T appoints new CFO after R Shankar Raman steps down",
                 "Larsen & Toubro announced a new chief financial officer.", mins=40),
        ])
        types = sorted(e["event_type"] for e in self.events("LT"))
        self.assertEqual(types, ["management_change", "order_win", "results"])

    def test_paid_content_dropped(self):
        self.run_items([item("et_markets", "https://et/p", "Brand Connect: Why HDFC Bank customers love X",
                             "HDFC Bank partner content")])
        self.assertEqual(self.events("HDFCBANK"), [])
        a = self.conn.execute("SELECT dropped_reason FROM articles").fetchone()
        self.assertIn("paid", a["dropped_reason"])

    def test_duplicate_url_ignored(self):
        it = item("et_markets", "https://et/d", "NTPC commissions 800 MW unit", "NTPC said...")
        self.run_items([it])
        self.run_items([it])
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM articles").fetchone()["c"], 1)

    def test_et_prime_stub_then_capture(self):
        url = "https://economictimes.indiatimes.com/prime/x"
        self.run_items([item("et_prime", url, "The related-party puzzle at ICICI Bank's subsidiary", "", is_stub=True)])
        d = dossier.build(self.conn, "ICICIBANK")
        self.assertTrue(any("Only the headline" in u["text"] for u in d["unknowns"]))
        self.run_items([item("et_prime", url, "The related-party puzzle at ICICI Bank's subsidiary",
                             "ICICI Bank's related-party transactions with its subsidiary rose sharply, "
                             "according to annual report filings reviewed by ET Prime.")])
        evs = self.events("ICICIBANK")
        self.assertEqual(len(evs), 1)
        self.assertEqual(evs[0]["event_type"], "governance_flag")
        self.assertEqual(evs[0]["validation"], "investigative")
        d = dossier.build(self.conn, "ICICIBANK")
        self.assertFalse(any("Only the headline" in u["text"] for u in d["unknowns"]))

    def test_dossier_citations(self):
        self.test_filing_confirms_press()
        d = dossier.build(self.conn, "LT")
        e = d["events"][0]
        self.assertEqual(e["corroboration"], 3)
        for n in e["citations"]:
            self.assertIn(str(n), d["citations"])
        for c in e["claims"]:
            self.assertTrue(c["citations"])
        self.assertEqual(d["citations"]["1"]["tier"], 0)   # filing cited first
        md = dossier.to_markdown(d)
        self.assertIn("[1]", md)
        self.assertIn("## Citations", md)


if __name__ == "__main__":
    unittest.main()


class TestCompanySearch(Base):
    FEED = b"""<rss><channel>
      <item><title>Reliance Industries Q2 profit rises 9% to Rs 19,323 crore - Mint</title>
        <link>https://news.google.com/rss/articles/abc</link><pubDate>Fri, 20 Nov 2026 10:00:00 GMT</pubDate>
        <source url="https://www.livemint.com">Mint</source></item>
      <item><title>RIL shares hit record high - Some Blog</title>
        <link>https://news.google.com/rss/articles/def</link><pubDate>Fri, 20 Nov 2026 11:00:00 GMT</pubDate>
        <source url="https://blog.example">Some Blog</source></item>
    </channel></rss>"""

    def test_publisher_mapping(self):
        from newsdesk.sources import parse_gnews, search_query
        items = parse_gnews(self.FEED, {"Mint": "mint"}, "web_other")
        self.assertEqual(items[0].source_id, "mint")
        self.assertEqual(items[0].title, "Reliance Industries Q2 profit rises 9% to Rs 19,323 crore")
        self.assertEqual(items[1].source_id, "web_other")
        self.assertEqual(search_query(["Axis Bank"], 7), '("Axis Bank") when:7d')
        self.run_items(items)
        self.assertEqual(len(self.events("RELIANCE")), 2)
        tier = self.conn.execute("SELECT tier FROM sources WHERE id='web_other'").fetchone()["tier"]
        self.assertEqual(tier, 2)

    def test_refresh_reports_failures(self):
        from unittest import mock
        from newsdesk import worker
        def fake(src, **kw):
            if src["kind"] == "gnews":
                from newsdesk.sources import parse_gnews
                return parse_gnews(self.FEED, src.get("publishers"), "web_other")
            raise ConnectionError("blocked")
        with mock.patch("newsdesk.sources.fetch", side_effect=fake):
            r = worker.refresh_ticker(self.conn, self.cfg, "RELIANCE", force=True)
        self.assertEqual(r["ok"], ["gnews"])
        self.assertTrue(all(f["error"].startswith("ConnectionError") for f in r["failed"]))
        self.assertEqual(r["items"], 2)
        self.assertTrue(self.events("RELIANCE"))

    def test_relink_after_adding_stock(self):
        from newsdesk.pipeline import relink, upsert_stock
        self.run_items([item("mint", "https://mint/t", "TCS wins $1 billion deal from UK insurer",
                             "Tata Consultancy Services said the deal runs seven years.")])
        self.assertEqual(self.events("TCS"), [])
        upsert_stock(self.conn, {"ticker": "TCS", "name": "Tata Consultancy Services",
                                 "aliases": ["TCS", "Tata Consultancy Services"]})
        relink(self.conn, self.cfg)
        self.assertEqual(len(self.events("TCS")), 1)


class TestCoverage(Base):
    def test_press_short_names_and_lookalikes(self):
        lk = Linker.from_db(self.conn)
        self.assertEqual(lk.link("Reliance shares rebound 15% in November", ""), {"RELIANCE": 0.6})
        self.assertEqual(lk.link("Reliance Power shares hit upper circuit", ""), {})
        self.assertEqual(lk.link("Anil Ambani's Reliance group faces ED probe", ""), {})
        self.assertEqual(lk.link("Jio adds 7.7 million subscribers in Q2", ""), {"RELIANCE": 0.4})
        self.assertEqual(lk.link("HDFC Life Q2 profit rises", ""), {})
        self.assertIn("HDFCBANK", lk.link("HDFC shares slip after deposit growth slows", ""))

    def test_routine_filings_skipped(self):
        self.run_items([item("bse", "https://bse/r", "Reliance Industries Ltd: Closure of Trading Window",
                             "", scrip="500325", category="Company Update")])
        self.assertEqual(self.events("RELIANCE"), [])
        r = self.conn.execute("SELECT dropped_reason FROM articles").fetchone()["dropped_reason"]
        self.assertTrue(r.startswith("routine filing"))

    def test_filing_pdf_supplies_the_numbers(self):
        import io
        from reportlab.pdfgen import canvas
        buf = io.BytesIO(); c = canvas.Canvas(buf)
        c.drawString(72, 750, "The Company has received an order worth Rs 2,100 crore from NHAI.")
        c.save()
        from pypdf import PdfReader
        def fetch(url):
            return " ".join(p.extract_text() for p in PdfReader(io.BytesIO(buf.getvalue())).pages)
        process(self.conn, [
            item("bse", "https://www.bseindia.com/x/order.pdf", "Larsen & Toubro Ltd: Disclosure under Regulation 30",
                 "", scrip="500510"),
            item("mint", "https://mint/o", "L&T wins ₹2,500 crore order from NHAI",
                 "Larsen & Toubro won an NHAI order.", mins=20)], self.cfg, pdf_fetcher=fetch)
        ev = self.events("LT")
        self.assertEqual(len(ev), 1, [dict(e) for e in ev])
        self.assertEqual(ev[0]["amount_cr"], 2100)
        self.assertEqual(ev[0]["validation"], "contradicted")   # press said 2,500

    def test_coming_up_from_board_notice(self):
        from datetime import date
        future = (datetime.now(timezone.utc) + timedelta(days=20)).astimezone(IST).date()
        when = future.strftime("%B %d, %Y")
        self.run_items([item("bse", "https://bse/bm", "Reliance Industries Ltd: Board Meeting Intimation",
                             f"The meeting of the Board of Directors will be held on {when} to consider "
                             "unaudited financial results for the quarter ended December 31, 2026.",
                             scrip="500325")])
        d = dossier.build(self.conn, "RELIANCE")
        self.assertEqual([(u["date"], u["what"]) for u in d["upcoming"]], [(future.isoformat(), "Results")])
        self.assertEqual(d["events"], [])        # a notice is not news; it isn't merged into results
        self.assertIn("## Coming up", dossier.to_markdown(d))


class TestServer(unittest.TestCase):
    """Starts the real HTTP server on a temp database and talks to it over localhost."""

    def test_ingest_and_dossier(self):
        import json, os, tempfile, threading, urllib.request
        from http.server import ThreadingHTTPServer
        tmp = tempfile.mkdtemp()
        os.environ["NEWSDESK_DB"] = os.path.join(tmp, "t.db")
        import importlib, newsdesk.config, newsdesk.db, newsdesk.server
        importlib.reload(newsdesk.config); importlib.reload(newsdesk.db)
        srv_mod = importlib.reload(newsdesk.server)
        conn = newsdesk.db.connect()
        cfg = bootstrap(conn)
        cfg["llm"] = {"enabled": False}
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), srv_mod.Handler)
        httpd.cfg = cfg
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"

        def call(path, body=None):
            req = urllib.request.Request(base + path, data=json.dumps(body).encode() if body else None,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req) as r:
                raw = r.read().decode()
                return json.loads(raw) if r.headers.get_content_type() == "application/json" else raw
        try:
            self.assertIn("<html", call("/").lower())
            r = call("/api/ingest", {"url": "https://economictimes.indiatimes.com/prime/y",
                                     "title": "NTPC's coal costs: a forensic audit question",
                                     "body": "NTPC faces a forensic audit over coal procurement, documents show."})
            self.assertTrue(r["events_changed"])
            d = call("/api/dossier/NTPC?refresh=no")
            self.assertEqual(d["events"][0]["type"], "governance_flag")
            self.assertIn("1", d["citations"])
            self.assertIn("## Citations", call("/api/dossier/NTPC?refresh=no&format=md"))
            call("/api/watchlist", {"ticker": "tcs", "name": "Tata Consultancy Services",
                                    "aliases": ["TCS", "Tata Consultancy Services"]})
            self.assertIn("TCS", [w["ticker"] for w in call("/api/watchlist")])
            self.assertTrue(call("/api/sources"))

            # headline batches: linked by symbol tag, credited to the real provider
            tv = "https://in.tradingview.com/news/reuters.com,2026:newsml_X:0/"
            r = call("/api/ingest/batch", {"items": [
                {"url": tv, "title": "Jio tariff hike lifts shares to record high",
                 "provider": "reuters.com,2026", "symbols": ["NSE:RELIANCE"],
                 "published_at": "2026-11-21T09:00:00Z"},
                {"url": "https://in.tradingview.com/news/x:1:0/", "title": "Apple unveils new iPhone",
                 "provider": "dow_jones", "symbols": ["NASDAQ:AAPL"]},
                {"title": "no url"}]})
            self.assertEqual((r["received"], r["usable"]), (3, 2))
            d = call("/api/dossier/RELIANCE?refresh=no")
            self.assertEqual(len(d["events"]), 1)
            c = d["citations"]["1"]
            self.assertEqual((c["source"], c["full_text_captured"]), ("Reuters", False))
            # opening the story later fills in its text; the symbol tag is kept
            call("/api/ingest", {"url": tv, "title": "Jio tariff hike lifts shares to record high",
                                 "provider": "reuters.com,2026",
                                 "body": "Shares rose 3% after the telecom arm raised tariffs. " * 8})
            d = call("/api/dossier/RELIANCE?refresh=no")
            self.assertEqual(len(d["events"]), 1)
            self.assertTrue(d["citations"]["1"]["full_text_captured"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            os.environ.pop("NEWSDESK_DB", None)
