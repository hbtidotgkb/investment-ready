"""Async side: polls sources on the market clock, runs fixed-time jobs, and serves
the on-demand refresh used before a dossier is built."""
import json
import logging
import threading
import time
from datetime import timedelta

from . import dossier, sources
from .clock import IST, iso, now_utc, parse_iso, phase
from .db import WRITE_LOCK, connect
from .pipeline import bootstrap, process, rescore_all

log = logging.getLogger("newsdesk.worker")

# (job name, IST hour, minute)
FIXED_JOBS = [("premarket_sweep_0700", 7, 0), ("premarket_prebuild_0845", 8, 45),
              ("nightly_maintenance_2300", 23, 0)]


FETCHED = ("rss", "bse", "gnews")   # other kinds (passive) only receive items


def stock_aliases(stock):
    return json.loads(stock["aliases"] or "[]") or [stock["name"]]


def run_source(conn, src, cfg, **kw):
    """Fetch one source and push items through the pipeline. Never raises.
    Returns {"source", "ok", "items", "error", "changed"}."""
    t0 = now_utc()
    try:
        items = sources.fetch(src, **kw)
        changed = process(conn, items, cfg)
        with WRITE_LOCK, conn:
            conn.execute("UPDATE sources SET last_run=?, last_ok=?, last_error=NULL WHERE id=?",
                         (iso(t0), iso(t0), src["id"]))
        log.info("%s: %d items, %d events changed", src["id"], len(items), len(changed))
        return {"source": src["id"], "ok": True, "items": len(items), "error": None, "changed": changed}
    except Exception as e:  # one broken feed must not stop the others
        err = f"{type(e).__name__}: {e}"[:300]
        with WRITE_LOCK, conn:
            conn.execute("UPDATE sources SET last_run=?, last_error=? WHERE id=?",
                         (iso(t0), err, src["id"]))
        log.warning("%s failed: %s", src["id"], err)
        return {"source": src["id"], "ok": False, "items": 0, "error": err, "changed": []}


def run_for_stock(conn, src, cfg, stock, days):
    if src["kind"] == "bse":
        if not stock["bse_scrip"]:
            return None
        return run_source(conn, src, cfg, scrip=stock["bse_scrip"], days=days)
    if src["kind"] == "gnews":
        return run_source(conn, src, cfg, aliases=stock_aliases(stock), days=days)
    return run_source(conn, src, cfg)


def refresh_ticker(conn, cfg, ticker, force=False):
    """On-demand path. Fetches only if this ticker's data is stale (or force)."""
    ticker = ticker.upper()
    st = conn.execute("SELECT last_ingest FROM ticker_state WHERE ticker=?", (ticker,)).fetchone()
    limit = cfg.get("freshness", {}).get("market" if phase() == "market" else "other", 30)
    last = parse_iso(st["last_ingest"]) if st and st["last_ingest"] else None
    last_poll = conn.execute("SELECT MAX(last_run) m FROM sources").fetchone()["m"]
    newest = max([x for x in (last, parse_iso(last_poll)) if x], default=None)
    if not force and newest and now_utc() - newest < timedelta(minutes=limit):
        return {"refreshed": False, "reason": "fresh"}

    stock = conn.execute("SELECT * FROM watchlist WHERE ticker=?", (ticker,)).fetchone()
    results = []
    for src in cfg.get("sources", []):
        if src["kind"] in FETCHED:
            r = run_for_stock(conn, src, cfg, stock, days=30 if force else 7)
            if r:
                results.append(r)
    with WRITE_LOCK, conn:
        conn.execute("INSERT INTO ticker_state VALUES(?,?) ON CONFLICT(ticker) DO UPDATE "
                     "SET last_ingest=excluded.last_ingest", (ticker, iso(now_utc())))
    return {"refreshed": True,
            "ok": [r["source"] for r in results if r["ok"]],
            "failed": [{"source": r["source"], "error": r["error"]} for r in results if not r["ok"]],
            "items": sum(r["items"] for r in results),
            "no_bse_scrip": not stock["bse_scrip"]}


class Worker(threading.Thread):
    def __init__(self, tick_seconds=30):
        super().__init__(daemon=True, name="newsdesk-worker")
        self.tick = tick_seconds
        self.stop_event = threading.Event()
        self.conn = connect()
        self.cfg = bootstrap(self.conn)

    def due(self, src, now):
        minutes = (src.get("cadence") or {}).get(phase(now), 0)
        if not minutes:
            return False
        row = self.conn.execute("SELECT last_run FROM sources WHERE id=?", (src["id"],)).fetchone()
        last = parse_iso(row["last_run"]) if row and row["last_run"] else None
        return last is None or now - last >= timedelta(minutes=minutes)

    def poll(self, src):
        """BSE's bulk feed and RSS run once; the company search runs per watchlist stock."""
        if src["kind"] not in FETCHED:
            return set()
        if src["kind"] == "gnews":
            res = [run_for_stock(self.conn, src, self.cfg, st, days=2)
                   for st in self.conn.execute("SELECT * FROM watchlist").fetchall()]
        else:
            res = [run_source(self.conn, src, self.cfg)]
        return {c["ticker"] for r in res if r for c in r["changed"]}

    def fixed_jobs(self, now):
        local = now.astimezone(IST)
        for name, h, m in FIXED_JOBS:
            target = local.replace(hour=h, minute=m, second=0, microsecond=0)
            if local < target or local - target > timedelta(hours=2):
                continue
            row = self.conn.execute("SELECT last_run FROM jobs WHERE name=?", (name,)).fetchone()
            if row and parse_iso(row["last_run"]).astimezone(IST).date() == local.date():
                continue
            log.info("running %s", name)
            if name.startswith("premarket"):
                for src in self.cfg["sources"]:
                    self.poll(src)
            if name.startswith("premarket_prebuild"):
                for r in self.conn.execute("SELECT ticker FROM watchlist").fetchall():
                    dossier.cache(self.conn, r["ticker"])
            if name.startswith("nightly"):
                rescore_all(self.conn)
            with WRITE_LOCK, self.conn:
                self.conn.execute("INSERT INTO jobs VALUES(?,?) ON CONFLICT(name) DO UPDATE "
                                  "SET last_run=excluded.last_run", (name, iso(now)))

    def run(self):
        log.info("worker started")
        while not self.stop_event.is_set():
            now = now_utc()
            try:
                self.fixed_jobs(now)
                touched = set()
                for src in self.cfg["sources"]:
                    if src["kind"] in FETCHED and self.due(src, now):
                        touched |= self.poll(src)
                for t in touched:          # event trigger: keep those dossiers warm
                    dossier.cache(self.conn, t)
            except Exception:
                log.exception("worker tick failed")
            self.stop_event.wait(self.tick)

    def stop(self):
        self.stop_event.set()
